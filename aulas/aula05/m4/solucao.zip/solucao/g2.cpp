#include <stdio.h>
#include <math.h>

int main() {
    int a, b;
    scanf("%d %d", &a, &b);

    int cont = 0;
    unsigned long int valor = 0;
    int num = 1;
    int aux = 3;

    do {
        valor = num * num * num;

        if(valor >= a && valor <= b)
            cont++;
        else {
            if(valor >= a)
                break;
        }

        num = num + aux;
        aux += 2;
    } while(1);

    printf("%d\n", cont);
    return 0;
}
