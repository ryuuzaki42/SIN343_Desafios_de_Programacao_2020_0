#include <math.h>
#include<iostream>

using namespace std;

int main() {
    int a, b, i, j, legal, temp, temp2;
    cin >> a;
    cin >> b;

    legal = 0;
    for(i = a; i <= b; i++) {
        temp = (int)sqrt(i);

        if((temp * temp) == i) {  //e quadrado
            temp2 = (int)cbrt(i);

            if((temp2 * temp2 * temp2) == i) //e cubo
                legal++;

            temp2++;
            if((temp2 * temp2 * temp2) == i) //e cubo
                legal++;
        }

        temp++;
        if((temp * temp) == i) { //e quadrado
            temp2 = (int)cbrt(i);

            if((temp2 * temp2 * temp2) == i) //e cubo
                legal++;

            temp2++;

            if((temp2 * temp2 * temp2) == i) //e cubo
                legal++;
        }
    }

    cout << legal << endl;
    return 0;
}
