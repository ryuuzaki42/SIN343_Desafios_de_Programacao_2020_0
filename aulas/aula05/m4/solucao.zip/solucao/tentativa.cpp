#include <stdio.h>
#include <math.h>

int main() {
    int a, b, i, j, legal, temp;
    double aux;
    scanf("%d", &a);
    scanf("%d", &b);
    legal = 0;

    for(i = a; i <= b; i++) {
        temp = sqrt(i);

        if((temp*temp) == i) { //e quadrado
            for(j = 1; j <= temp; j++) {
                if((j * j * j) == i) //e cubo
                    legal++;
            }
        }
    }

    printf("%d\n", legal);
    return 0;
}
