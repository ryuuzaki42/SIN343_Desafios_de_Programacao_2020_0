////////              File : ArvBinPesq.h              ////////
// Declaração e implementação de uma classe genérica que     //
// representa uma Árvore Binária de Pesquisa                 //
// A implementação utiliza dois parâmetros de tipo TE e TC   //
// sendo que TE define o Tipo do Elemento e TC o Tipo da     //
// Chave usada nas operações de pesquisa. Na verdade, cada   //
// nó da árvore irá conter o valor da chave e um apontador   //
// referenciando os dados do item associado aquela chave.    //
// É suposto que se a chave não é um tipo básico, a classe   //
// TC deve incluir a sobrecarga dos operadores de comparação //
// >, < e ==.                                                //
// Implementado por Marcus V. Andrade                        //
// Adaptado por Guilherme de Castro Pena                      //
////////                                               ////////

#ifndef ARVBINPESQ_H
#define ARVBINPESQ_H

#include <iostream>

using namespace std;

// encaminha a declaracao da class ArvBinPesq
template <class TE, class TC>
class ArvBinPesq;

//Classe No da Arvore
template <class TE, class TC>
class NodoABP {
    friend class ArvBinPesq<TE,TC>;

    template <class TE2, class TC2>
    friend ostream & operator << (ostream &, const NodoABP<TE2,TC2>* p);

public:
    NodoABP();
    NodoABP(const TC &k, TE *pi, NodoABP<TE,TC>* fe=NULL, NodoABP<TE,TC>* fd=NULL);

    TE* get() {
        return pitem;
    }
    TC& getChave() {
        return chave;
    }

private:

    TC chave;
    TE *pitem;

    NodoABP<TE,TC>* fesq;
    NodoABP<TE,TC>* fdir;
};

//Sobrecarga do operador << para a classe NodoABP
template <class TE2, class TC2>
ostream & operator << (ostream &, const NodoABP<TE2,TC2>* p) {
    cout << "[" << p->chave << ", " << *(p->pitem) << "] ";
}

/*
+-----------------------------------------------------+
|     Implementacao das funcoes da classe NodoABP     |
+- ---------------------------------------------------+
*/

template<class TE, class TC>
NodoABP<TE,TC>::NodoABP() {
    pitem=NULL;
    fesq=NULL;
    fdir=NULL;
}

template<class TE, class TC>
NodoABP<TE,TC>::NodoABP(const TC &k, TE *pi, NodoABP<TE,TC>* fe, NodoABP<TE,TC>* fd) {
    chave=k;
    pitem=pi;
    fesq=fe;
    fdir=fd;
}

//Classe Arvore
template <class TE, class TC>
class ArvBinPesq  {

    template <class TE2, class TC2>
    friend ostream & operator << (ostream &, const ArvBinPesq<TE2,TC2>& t);

public:

    ArvBinPesq();
    ArvBinPesq(TC, TE *);
    ArvBinPesq(const ArvBinPesq<TE,TC> &);
    ~ArvBinPesq();

    ArvBinPesq<TE,TC> &operator=(const ArvBinPesq<TE,TC> &);

    NodoABP<TE,TC> * localiza(const TC& k) const;
    bool insere(const TC &k, TE *pi);
    bool elimina(const TC &k);
    NodoABP<TE,TC>* max() const;
    NodoABP<TE,TC>* min() const;

    void imprime() const;

private:
    NodoABP<TE,TC> *raiz;

    NodoABP<TE,TC> * localiza(const TC & k, NodoABP<TE,TC> *p) const;
    bool insere(const TC &k, TE *pi, NodoABP<TE,TC> * &p);
    bool elimina(const TC &k, NodoABP<TE,TC> * &p);
    bool substitui(NodoABP<TE,TC> *p, NodoABP<TE,TC> * &r);

    NodoABP<TE,TC>* max(NodoABP<TE,TC> *p) const;
    NodoABP<TE,TC>* min(NodoABP<TE,TC> *p) const;

    void imprime(NodoABP<TE,TC>* p) const;

    NodoABP<TE,TC>* copiaArv(const NodoABP<TE,TC>* p);
    void apagaArv(NodoABP<TE,TC>* p);
};

/*
+-----------------------------------------------------+
|     Implementacao das funcoes da classe ArvBinPesq  |
+- ---------------------------------------------------+
*/

//
// Metodos publicos
//

template <class TE, class TC>
ArvBinPesq<TE,TC>::ArvBinPesq() {
    raiz=NULL;
}

template <class TE, class TC>
ArvBinPesq<TE,TC>::ArvBinPesq(TC k, TE *pi) {
    raiz = new NodoABP<TE,TC>(k,pi);
};

template <class TE, class TC>
ArvBinPesq<TE,TC>::ArvBinPesq(const ArvBinPesq<TE,TC> &t) {
    raiz = copiaArv(t.raiz);
};

template <class TE, class TC>
ArvBinPesq<TE,TC>::~ArvBinPesq() {
    apagaArv(raiz);
};

template <class TE, class TC>
ArvBinPesq<TE,TC> & ArvBinPesq<TE,TC>::operator= (const ArvBinPesq<TE,TC> &t) {
    if(this != &t) {
        apagaArv(raiz);
        raiz = copiaArv(t.raiz);
    }

    return (*this);
};

template <class TE, class TC>
NodoABP<TE,TC>* ArvBinPesq<TE,TC>::localiza(const TC& k) const {
    return localiza(k,raiz);
}

template <class TE, class TC>
bool ArvBinPesq<TE,TC>::insere(const TC &k, TE *pi) {
    return insere(k,pi,raiz);
}

template <class TE, class TC>
bool ArvBinPesq<TE,TC>::elimina(const TC &k) {
    return elimina(k,raiz);
}

template <class TE, class TC>
NodoABP<TE,TC> *ArvBinPesq<TE,TC>::max() const {
    return max(raiz);
}

template <class TE, class TC>
NodoABP<TE,TC> *ArvBinPesq<TE,TC>::min() const {
    return min(raiz);
}

template <class TE, class TC>
void ArvBinPesq<TE,TC>::imprime() const {
    imprime(raiz);
    cout << "\n";
}

//
// Metodos privados
//

template <class TE, class TC>
NodoABP<TE,TC>* ArvBinPesq<TE,TC>::localiza(const TC& k, NodoABP<TE,TC> *p) const {
    // supondo que os operadores >, < e == estao sobrecarregados para
    // objetos do tipo da chave e objetos do tipo T
    if(p==NULL)
        return NULL;
    else {
        if(k < p->chave)
            return localiza(k,p->fesq);
        else {
            if(k > p->chave)
                return localiza(k,p->fdir);
            else
                return p;
        }
    }
}

template <class TE, class TC>
bool ArvBinPesq<TE,TC>::insere(const TC &k, TE *pi, NodoABP<TE,TC> * &p) {
    // supondo que os operadores >, < e == estao sobrecarregados para
    // objetos do tipo T
    if(!p) {  // subarvore vazia -- ponto de insercao
        p = new NodoABP<TE,TC> (k,pi);
        return true;
    } else {
        if(k < p->chave) return insere(k,pi,p->fesq);
        else if(k > p->chave) return insere(k,pi,p->fdir);
        else return false;  // elemento com a mesma chave ja existe na arvore
    }
}

template <class TE, class TC>
bool ArvBinPesq<TE,TC>::elimina(const TC &k, NodoABP<TE,TC> * &p) {
    // supondo que os operadores >, < e == estao sobrecarregados para
    // objetos do tipo T
    if(!p)  // o item x nao esta na arvore
        return false;
    else if(k < p->chave)
        return elimina(k,p->fesq);
    else if(k > p->chave)
        return elimina(k,p->fdir);
    else {
        NodoABP<TE,TC> *aux = p;

        if(!p->fesq) {
            p=p->fdir;
            delete aux;
            return true;
        } else if(!p->fdir) {
            p=p->fesq;
            delete aux;
            return true;
        } else
            return substitui(p,p->fesq);
    }
}

template <class TE, class TC>
bool ArvBinPesq<TE,TC>::substitui(NodoABP<TE,TC> *p, NodoABP<TE,TC> * &r) {
    if(r->fdir)
        return substitui(p,r->fdir);
    else {
        p->chave = r->chave;
        p->pitem = r->pitem;
        p=r;
        r=r->fesq;
        delete p;
        return true;
    }
}

template <class TE, class TC>
NodoABP<TE,TC> *ArvBinPesq<TE,TC>::max(NodoABP<TE,TC> *p) const {
    if(p->fdir) return max(p->fdir);
    else return p;
}

template <class TE, class TC>
NodoABP<TE,TC> *ArvBinPesq<TE,TC>::min(NodoABP<TE,TC> *p) const {
    if(p->fesq) return min(p->fesq);
    else return p;
}

template <class TE2, class TC2>
ostream& operator << (ostream &fout, const ArvBinPesq<TE2,TC2>& t) {
    t.imprime();
    return fout;
}

template <class TE, class TC>
void ArvBinPesq<TE,TC>::imprime(NodoABP<TE,TC> *p) const {
    // supondo que o operador << esta sobrecarregado para o tipo T
    if(!p) return;

    imprime(p->fesq);
    cout << "   " << p;
    imprime(p->fdir);
}

template <class TE, class TC>
NodoABP<TE,TC>* ArvBinPesq<TE,TC>::copiaArv(const NodoABP<TE,TC> *p) {
    if(!p)
        return NULL;

    return new NodoABP<TE,TC> (p->chave, p->pitem, copiaArv(p->fesq), copiaArv(p->fdir));
}

template <class TE, class TC>
void ArvBinPesq<TE,TC>::apagaArv(NodoABP<TE,TC> *p) {
    if(p) {
        apagaArv(p->fesq);
        apagaArv(p->fdir);
        delete p;
    }
}

#endif
