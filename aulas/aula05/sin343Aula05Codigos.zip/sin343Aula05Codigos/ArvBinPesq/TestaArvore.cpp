/////                          /////
// Testa a implementacao de Lista //
////                           /////
#include <iostream>
#include <limits.h>
#include "ArvBinPesq.h"
using namespace std;

class Elem {
    friend ostream & operator << (ostream &, const Elem& e);
public:
    Elem(char c='\0', float x=0) {
        ch=c;
        it=x;
    }
    void set(char c, float x) {
        ch=c;
        it=x;
    }
    char chave() const {
        return ch;
    }
private:
    char ch;
    float it;
};

ostream & operator << (ostream & fout, const Elem& e) {
    fout << "<" << e.ch << "," << e.it << ">";
    return fout;
}

int main() {
    Elem *pe;
    ArvBinPesq<Elem,char> t;
    pe = new Elem('M',25);
    t.insere(pe->chave(), pe);
    pe = new Elem('F',10);
    t.insere(pe->chave(), pe);
    pe = new Elem('C',5);
    t.insere(pe->chave(), pe);
    pe = new Elem('J',9);
    t.insere(pe->chave(), pe);
    pe = new Elem('R',55);
    t.insere(pe->chave(), pe);
    pe = new Elem('P',3);
    t.insere(pe->chave(), pe);
    pe = new Elem('T',1);
    t.insere(pe->chave(), pe);
    pe = new Elem('B',2);
    t.insere(pe->chave(), pe);
    t.imprime();
    cout << endl;
    NodoABP<Elem,char>* p = t.localiza('C');

    if(p)
        cout << "Elemento = " << *(p->get()) << endl;
    else
        cout << "Elemento com chave C NAO existe\n";

    cout << "\nO maior elemento eh " << *(t.max()->get()) << endl;

    if(t.elimina('J'))
        cout << "Elemento com chave J removido com sucesso\n";
    else
        cout << "Elemento com chave J NAO existe\n";

    t.imprime();
    {
        cout << "\nTestando o construtor de copia \n";
        ArvBinPesq<Elem,char> aux(t); // chamando construtor de copia
        cout << "Arvore t   = ";
        t.imprime();
        cout << endl;
        cout << "Arvore aux = ";
        aux.imprime();
        cout << endl;
        pe = new Elem('X',23);
        aux.insere('X',pe);
        cout << "Arvore t   = ";
        t.imprime();
        cout << endl;
        cout << "Arvore aux = ";
        aux.imprime();
        cout << endl;
    } // destrutor da arvore aux foi chamado
    cout << "\nTestando o operador de atribuicao \n";
    ArvBinPesq<Elem,char> aux;
    aux = t;
    cout << "Arvore t   = ";
    t.imprime();
    cout << endl;
    cout << "Arvore aux = ";
    aux.imprime();
    cout << endl;
    pe = new Elem('K',18);
    aux.insere('K', pe);
    cout << "Arvore t   = ";
    t.imprime();
    cout << endl;
    cout << "Arvore aux = ";
    aux.imprime();
    cout << endl;
    cout << "\n\nTestando auto atribuicao \n";
    aux = aux;
    cout << "Arvore aux = ";
    aux.imprime();
    cout << endl;
    return 0;
}

/*
--------------- SAIDA ESPERADA ------------------------------

   [B,2]   [C,5]   [F,10]   [J,9]   [M,25]   [P,3]   [R,55]   [T,1]

Elemento = [C,5]

O maior elemento eh [T,1]
Elemento com chave J removido com sucesso
   [B,2]   [C,5]   [F,10]   [M,25]   [P,3]   [R,55]   [T,1]

Testando o construtor de copia
Arvore t   =    [B,2]   [C,5]   [F,10]   [M,25]   [P,3]   [R,55]   [T,1]

Arvore aux =    [B,2]   [C,5]   [F,10]   [M,25]   [P,3]   [R,55]   [T,1]

Arvore t   =    [B,2]   [C,5]   [F,10]   [M,25]   [P,3]   [R,55]   [T,1]

Arvore aux =    [B,2]   [C,5]   [F,10]   [M,25]   [P,3]   [R,55]   [T,1]   [X,23]

Testando o operador de atribuicao
Arvore t   =    [B,2]   [C,5]   [F,10]   [M,25]   [P,3]   [R,55]   [T,1]

Arvore aux =    [B,2]   [C,5]   [F,10]   [M,25]   [P,3]   [R,55]   [T,1]

Arvore t   =    [B,2]   [C,5]   [F,10]   [M,25]   [P,3]   [R,55]   [T,1]

Arvore aux =    [B,2]   [C,5]   [F,10]   [K,18]   [M,25]   [P,3]   [R,55]   [T,1]

Testando auto atribuicao
Arvore aux =    [B,2]   [C,5]   [F,10]   [K,18]   [M,25]   [P,3]   [R,55]   [T,1]

*/
