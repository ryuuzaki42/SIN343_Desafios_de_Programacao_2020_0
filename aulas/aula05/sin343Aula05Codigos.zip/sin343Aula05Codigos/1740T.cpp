#include <iostream>
#include <stdio.h>
#include <vector>
#include <bits/stdc++.h>
#include <limits>

using namespace std;

// A Treap Node
struct TreapNode {
    int key, priority, valor;
    TreapNode *left, *right;
};

int chave = 1;

TreapNode *rightRotate(TreapNode *y) {
    TreapNode *x = y->left, *T2 = x->right;
    x->right = y;
    y->left = T2;
    return x;
}

TreapNode *leftRotate(TreapNode *x) {
    TreapNode *y = x->right, *T2 = y->left;
    y->left = x;
    x->right = T2;
    return y;
}

/* Utility function to add a new key */
TreapNode* newNode(int key, int val) {
    TreapNode* temp = new TreapNode;
    temp->key = key;
    chave++;
    temp->valor = val;
    temp->priority = rand()%INT_MAX;
    //temp->priority = cont++;
    temp->left = temp->right = NULL;
    return temp;
}

// C function to search a given key in a given BST
TreapNode* search(TreapNode* root, int key) {
    // Base Cases: root is null or key is present at root
    if(root == NULL || root->key == key)
        return root;

    // Key is greater than root's key
    if(root->key < key)
        return search(root->right, key);

    // Key is smaller than root's key
    return search(root->left, key);
}

/* Recursive implementation of insertion in Treap */
TreapNode* insert(TreapNode* root, int key, int val) {
    // If root is NULL, create a new node and return it
    if(!root)
        return newNode(key, val);

    // If key is smaller than root
    if(key <= root->key) {
        // Insert in left subtree
        root->left = insert(root->left, key, val);

        // Fix Heap property if it is violated
        if(root->left->priority > root->priority)
            root = rightRotate(root);
    } else { // If key is greater
        // Insert in right subtree
        root->right = insert(root->right, key, val);

        // Fix Heap property if it is violated
        if(root->right->priority > root->priority)
            root = leftRotate(root);
    }

    return root;
}

/* Recursive implementation of Delete() */
TreapNode* deleteNode(TreapNode* root, int key) {
    if(root == NULL)
        return root;

    if(key < root->key)
        root->left = deleteNode(root->left, key);
    else if(key > root->key)
        root->right = deleteNode(root->right, key);
    // IF KEY IS AT ROOT
    // If left is NULL
    else if(root->left == NULL) {
        TreapNode *temp = root->right;
        delete(root);
        root = temp; // Make right child as root
    }
    // If Right is NULL
    else if(root->right == NULL) {
        TreapNode *temp = root->left;
        delete(root);
        root = temp; // Make left child as root
    }
    // If key is at root and both left and right are not NULL
    else if(root->left->priority < root->right->priority) {
        root = leftRotate(root);
        root->left = deleteNode(root->left, key);
    } else {
        root = rightRotate(root);
        root->right = deleteNode(root->right, key);
    }

    return root;
}

void limpaArvore(TreapNode* root) {
    if(root) {
        limpaArvore(root->left);
        limpaArvore(root->right);
        delete(root);
    }
}

void troca(int *a, int *b) {
    int c = *a;
    *a = *b;
    *b = c;
}

int main() {
    int n, c;
    int id, x, y;
    srand(time(NULL));

    while(cin >> n) {
        chave = 1;
        struct TreapNode *root = NULL;
        int i, j, elem, ind;

        for(i=0; i<n; i++) {
            cin >> elem;
            root = insert(root, chave, elem);
        }

        cin >> c;

        for(i=0; i<c; i++) {
            cin >> id;
            TreapNode *ex, *ey;

            /*for(j=1; j<chave; j++){
                ex = search(root, j);
                cout << ex->valor << " ";
            }
            cout << endl;*/
            switch(id) {
                case 0:
                    cin >> x >> y;
                    ex = search(root, x);
                    ey = search(root, y);
                    troca(&ex->valor, &ey->valor);
                    break;

                case 1:
                    cin >> x >> y;
                    ex = search(root, x);
                    ex->valor = y;
                    break;

                case 2:
                    cin >> x >> y;

                    for(j=chave-1; j>=x; j--) {
                        ex = search(root, j);
                        ex->key++;
                    }

                    root = insert(root, x, y);
                    break;

                case 3:
                    cin >> x;
                    root = deleteNode(root, x);

                    for(j=x+1; j<chave; j++) {
                        ex = search(root, j);
                        ex->key--;
                    }

                    chave--;
                    break;

                case 4:
                    cin >> x >> y;
                    bool equal = true, cresc = false, decresc = false;
                    bool dif = false;
                    ex = search(root, x);

                    if(y-x > 0)
                        while(x<y) {
                            ey = search(root, x+1);

                            if(ex->valor == ey->valor && !dif)
                                equal = true;
                            else {
                                equal = false;
                                dif = true;

                                if(cresc && decresc)
                                    break;

                                if(ex->valor <= ey->valor)
                                    cresc = true;
                                else {
                                    if(ex->valor >= ey->valor)
                                        decresc = true;
                                }
                            }

                            x++;
                            ex = search(root, x);
                        }

                    /*for(j=0; j<(y-x); j++)
                    if(lista[j] == lista[j+1] && !dif)
                    equal = true;
                    else{
                    equal = false;
                          dif = true;
                          if(cresc && decresc){
                    break;
                                 }
                           if(lista[j] <= lista[j+1])
                      cresc = true;
                                 else{
                              if(lista[j] >= lista[j+1])
                           decresc = true;
                                     }
                        }*/

                    if(equal)
                        cout << "ALL EQUAL\n";
                    else if(cresc && decresc)
                        cout << "NONE\n";
                    else if(cresc)
                        cout << "NON DECREASING\n";
                    else if(decresc)
                        cout << "NON INCREASING\n";

                    break;
            }

            //for(itx=lista.begin(); itx!=lista.end(); itx++)  cout << *itx << " "; cout << endl;
            //cout << endl;
        }

        limpaArvore(root);
    }

    return 0;
}
