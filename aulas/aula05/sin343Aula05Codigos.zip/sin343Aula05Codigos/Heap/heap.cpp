#include <iostream>

using namespace std;

int cont = 0;

void troca(int &a, int &b) {
    int aux = a;
    a = b;
    b = aux;
}

void heap(int *h, int ini, int fim) {
    int k, v;
    bool heap;//Satisfaz Propriedade

    for(int i=fim/2; i>=ini; i--) {
        k = i;
        v = h[k];
        heap = false;

        while(!heap && 2*k <= fim) {
            int j = 2*k;

            if(j<fim)
                //Maior Filho
                if(h[j] < h[j+1])
                    j++;

            if(v >= h[j])
                heap = true;
            else {
                h[k] = h[j];
                k = j;
            }
        }

        h[k] = v;
    }
}

void heapsort(int *h, int ini, int fim) {
    for(int i=ini; i<=fim; i++) {
        heap(h, ini, fim-i+1);
        troca(h[fim-i+1], h[ini]);
    }
}

int main() {
    int n;
    cin >> n;
    int *v = new int[n+1];
    int i;

    for(i = 1; i<= n; i++)
        cin >> v[i];

    cout << "Antes:\n";

    for(i = 1; i<= n; i++)
        cout << v[i] << " ";

    cout << endl;
    cout << endl;
    //heapsort(v, 1, n);
    heap(v, 1, n);
    cout << "Final:\n";

    for(i = 1; i<= n; i++)
        cout << v[i] << " ";

    cout << endl;
    cout << cont << " comparacoes\n";
    delete [] v;
    return 0;
}
