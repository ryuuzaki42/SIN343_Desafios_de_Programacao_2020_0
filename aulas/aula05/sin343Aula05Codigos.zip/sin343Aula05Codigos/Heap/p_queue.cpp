#include <iostream>
#include <limits.h>

using namespace std;

#define N 100

void imprime(int *h, int ini, int fim) {
    for(int i = ini; i<= fim; i++)
        cout << h[i] << " ";

    cout << endl;
}

void troca(int &a, int &b) {
    int aux = a;
    a = b;
    b = aux;
}

void heap(int *h, int ini, int fim) {
    int k, v;
    bool heap;//Satisfaz Propriedade

    for(int i=fim/2; i>=ini; i--) {
        k = i;
        v = h[k];
        heap = false;

        while(!heap && 2*k <= fim) {
            int j = 2*k;

            if(j<fim)
                //Maior Filho
                if(h[j] < h[j+1])
                    j++;

            if(v >= h[j])
                heap = true;
            else {
                h[k] = h[j];
                k = j;
            }
        }
        h[k] = v;
    }
}

int removeMax(int *h, int ini, int &fim) {
    int max = h[ini];
    h[ini] = h[fim];
    fim --;
    heap(h, 1, fim);
    return max;
}

void aumentaChave(int *h, int ini, int fim, int chave) {
    if(chave < h[fim]) {
        cout << "Error: Nova chave e menor que chave atual!\n";
        return;
    }

    h[fim] = chave;

    while(fim > 1 && h[fim/2] < h[fim]) {
        troca(h[fim], h[fim/2]);
        fim = fim/2;
    }
}

void insere(int *h, int ini, int &fim, int chave) {
    fim++;//Nao testa tamanho maximo do conjunto (N == 100)
    h[fim] = INT_MIN; // Valor muito pequeno
    aumentaChave(h, ini, fim, chave);
}

int main() {
    int n;
    cin >> n;
    int *v = new int[N];
    int i;

    for(i = 1; i<= n; i++)
        cin >> v[i];

    cout << "Antes:\n";
    imprime(v, 1, n);
    cout << endl;
    heap(v, 1, n);
    cout << "Depois:\n";
    imprime(v, 1, n);
    cout << endl;
    int m = removeMax(v, 1, n);
    cout << "Max: " << m << endl;
    cout << "Depois Remover Max:\n";
    imprime(v, 1, n);
    cout << endl;
    insere(v, 1, n, 6);
    cout << "Depois Inserir:\n";
    imprime(v, 1, n);
    cout << endl;
    delete [] v;
    return 0;
}
