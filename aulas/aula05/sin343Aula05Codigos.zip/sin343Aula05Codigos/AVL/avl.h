
#ifndef __avl_h
#define __avl_h

/////////////////////// avl.h //////////////////////////////////
// Declara��o e implementa��o de uma classe gen�rica que      //
// representa uma �rvore Bin�ria de Pesquisa Balanceada (AVL) //
// A implementa��o utiliza dois par�metros de tipo TE e TC    //
// sendo que o no contem uma chave TC e um apontodor para o   //
// objeto do tipo correspondente a chave                      //
// Implementado por Marcus V. Andrade                         //
// Adaptado por Guilherme de Castro Pena                      //
////////                                                ////////

#include <fstream>
#include <exception>
#include <cstring>

using namespace std;

// Classe definida para tratar exce��es nas opera��es de inser��o e
// remo��o de elementos numa �rvore
class Erro_Arv {
private:
    char msg[100];
public:
    Erro_Arv(const char *s) {
        strcpy(msg, s);
    }
    char *what() {
        return msg;
    }
};

// Classe definida para tratar exce��es na opera��o de localiza��o de
// elementos numa �rvore
class Erro_Localiza {
    // usado apenas para indicar que n�o localizou objeto procurado
};

template<class TE, class TC>
class AVL;

template<class TE, class TC>
class NodoAVL { // nodos da �rvore

    template <class TE2, class TC2>
    friend ostream & operator << (ostream &, const NodoAVL<TE2,TC2>* p);

public:
    AVL<TE,TC> esq, dir;//Sub-arvores Esq e Dir
    TE *pelem;
    TC chave;
    int bal;
    NodoAVL(const TC &k, TE *pe, int b, const AVL<TE,TC> &a1, const AVL<TE,TC> &a2)
        : esq(a1), bal(b), dir(a2), chave(k), pelem(pe) {
    }
    NodoAVL(const TC &k, TE *pe) : chave(k), pelem(pe) {
        bal = 0;
    }
};

template <class TE2, class TC2>
ostream & operator << (ostream & fout, const NodoAVL<TE2,TC2>* p) {
    fout << "[" << p->chave << ", " << *(p->pelem) << "] ";
    return fout;
}

template<class TE, class TC>
class AVL {
    template <class TE2, class TC2>
    friend ostream & operator << (ostream &, const AVL<TE2,TC2>& t);
public:
    AVL() {
        raiz = NULL;    // construtor default
    }
    ~AVL() {
        delete raiz;    // destrutor
    }
    AVL(const AVL&);                 // construtor de c�pia
    AVL& operator= (const AVL&);     // operador de atribui��o

    TE& localiza(const TC &k) const;
    // localiza elemento cuja chave eh igual a k;
    // a resposta � uma refer�ncia ao elemento (resp);
    // se nao encontrar lan�a uma exce��o

    void insere(const TC &k, TE *pe);
    // insere o elemento x;
    // lan�a uma exce��o caso ja exista um elemento com a mesma chave

    void elimina(const TC &k);
    // elimina elemento cuja chave � igual a k;
    // lan�a uma exce��o caso nao ja exista um elemento com a mesma chave

    bool vazia() const; // verifica se a �rvore � vazia

    void imprime(ostream&) const;

    void imp_forma(int k) const;

private:
    NodoAVL<TE,TC> *raiz; // aponta para o nodo raiz

    int insere_aux(const TC &k, TE *pe);
    int elimina_aux(const TC &k);

    void verifica_balanco();
    void LL();
    void RR();
    void LR();
    void RL();
    int eliminaMax(NodoAVL<TE,TC> *);
};

template<class TE, class TC>
TE& AVL<TE,TC>::localiza(const TC &k) const {
    if(! raiz)
        throw Erro_Localiza();

    if(k < raiz->chave)
        return raiz->esq.localiza(k);

    if(k > raiz->chave)
        return raiz->dir.localiza(k);

    return *(raiz->pelem);
}

template<class TE, class TC>
void AVL<TE,TC>::insere(const TC &k, TE *pe) {
    insere_aux(k,pe);
}

template<class TE, class TC>
int AVL<TE,TC>::insere_aux(const TC &k, TE *pe) {
    if(! raiz) {
        raiz = new NodoAVL<TE,TC>(k,pe);
        return 1;
    }

    int antbal = raiz->bal;

    if(k < raiz->chave)
        raiz->bal -= raiz->esq.insere_aux(k,pe);
    else if(k > raiz->chave)
        raiz->bal += raiz->dir.insere_aux(k,pe);
    else
        throw Erro_Arv("Elemento repetido em \"Insere\"");

    verifica_balanco();
    return (antbal == 0 && raiz->bal != 0);
}

template<class TE, class TC>
void AVL<TE,TC>::verifica_balanco() {
    if(raiz->bal == -2)
        if(raiz->esq.raiz->bal <= 0)
            LL();
        else // raiz->esq.raiz->bal == 1
            LR();
    else if(raiz->bal == 2)
        if(raiz->dir.raiz->bal >= 0)
            RR();
        else // raiz->dir.raiz->bal == -1
            RL();
}

template<class TE, class TC>
void AVL<TE,TC>::LL() {
    NodoAVL<TE,TC> *auxA = raiz;
    raiz = raiz->esq.raiz;
    auxA->esq.raiz = raiz->dir.raiz;
    raiz->dir.raiz = auxA;

    if(raiz->bal == -1) {
        auxA->bal = 0;
        raiz->bal = 0;
    } else { // raiz->bal == 0, s� acontece em elimina��o
        auxA->bal = -1;
        raiz->bal = 1;
    }
}

template<class TE, class TC>
void AVL<TE,TC>::RR() {
    NodoAVL<TE,TC> *auxA = raiz;
    raiz = raiz->dir.raiz;
    auxA->dir.raiz = raiz->esq.raiz;
    raiz->esq.raiz = auxA;

    if(raiz->bal == 1) {
        auxA->bal = 0;
        raiz->bal = 0;
    } else { // raiz->bal == 0, s� acontece em elimina��o
        auxA->bal = 1;
        raiz->bal = -1;
    }
}

template<class TE, class TC>
void AVL<TE,TC>::LR() {
    NodoAVL<TE,TC> *auxA = raiz;
    NodoAVL<TE,TC> *auxB = raiz->esq.raiz;
    raiz = auxB->dir.raiz;
    auxA->esq.raiz = raiz->dir.raiz;
    auxB->dir.raiz = raiz->esq.raiz;
    raiz->esq.raiz = auxB;
    raiz->dir.raiz = auxA;

    if(raiz->bal == -1) {
        auxB->bal = 0;
        auxA->bal = 1;
    } else if(raiz->bal == 1) {
        auxB->bal = -1;
        auxA->bal = 0;
    } else { // raiz->bal == 0, s� acontece em elimina��o
        auxB->bal = 0;
        auxA->bal = 0;
    }

    raiz->bal = 0;
}

template<class TE, class TC>
void AVL<TE,TC>::RL() {
    NodoAVL<TE,TC> *auxA = raiz;
    NodoAVL<TE,TC> *auxB = raiz->dir.raiz;
    raiz = auxB->esq.raiz;
    auxA->dir.raiz = raiz->esq.raiz;
    auxB->esq.raiz = raiz->dir.raiz;
    raiz->esq.raiz = auxA;
    raiz->dir.raiz = auxB;

    if(raiz->bal == -1) {
        auxA->bal = 0;
        auxB->bal = 1;
    } else if(raiz->bal == 1) {
        auxA->bal = -1;
        auxB->bal = 0;
    } else { // raiz->bal == 0
        auxA->bal = 0;
        auxB->bal = 0;
    }

    raiz->bal = 0;
}

template<class TE, class TC>
void AVL<TE,TC>::elimina(const TC &k) {
    elimina_aux(k);
}

template<class TE, class TC>
int AVL<TE,TC>::elimina_aux(const TC &k) {
    if(! raiz)
        throw Erro_Arv("Elemento n�o encontrado em \"Elimina\"");

    int antbal = raiz->bal;

    if(k < raiz->chave)
        raiz->bal += raiz->esq.elimina_aux(k);
    else if(k > raiz->chave)
        raiz->bal -= raiz->dir.elimina_aux(k);
    else if(raiz->esq.vazia()) {
        NodoAVL<TE,TC> *aux = raiz;
        raiz = raiz->dir.raiz;
        aux->dir.raiz = NULL;
        delete aux;
        return 1;
    } else if(raiz->dir.vazia()) {
        NodoAVL<TE,TC> *aux = raiz;
        raiz = raiz->esq.raiz;
        aux->esq.raiz = NULL;
        delete aux;
        return 1;
    } else
        raiz->bal += raiz->esq.eliminaMax(raiz->elem);

    verifica_balanco();
    return (antbal != 0 && raiz->bal == 0);
}

template<class TE, class TC>
int AVL<TE,TC>::eliminaMax(NodoAVL<TE,TC> *p) {
    if(raiz->dir.vazia()) {
        p->chave = raiz->chave;
        p->pelem = raiz->pelem;
        NodoAVL<TE,TC> *aux = raiz;
        raiz = raiz->esq.raiz;
        aux->esq.raiz = NULL;
        delete aux;
        return 1;
    }

    int antbal = raiz->bal;
    raiz->bal -= raiz->dir.eliminaMax(p);
    verifica_balanco();
    return (antbal == 1 && raiz->bal == 0);
}

template<class TE, class TC>
bool AVL<TE,TC>::vazia() const {
    return raiz == NULL;
}

template<class TE2, class TC2>
ostream& operator<< (ostream &os, const AVL<TE2,TC2> &a) {
    a.imprime(os);
    return os;
}

template<class TE, class TC>
void AVL<TE,TC>::imprime(ostream &os) const {
    // supondo que o operador << esta sobrecarregado para o tipo T
    if(raiz) {
        raiz->esq.imprime(os);
        os << *(raiz->pelem) << "  ";
        raiz->dir.imprime(os);
    }
}

template<class TE, class TC>
AVL<TE,TC>::AVL(const AVL<TE,TC> &a) {
    if(a.vazia())
        raiz = NULL;
    else
        raiz = new NodoAVL<TE,TC> (a.raiz->chave, a.raiz->pelem, a.raiz->bal, a.raiz->esq, a.raiz->dir);
}

template<class TE, class TC>
AVL<TE,TC>& AVL<TE,TC>::operator= (const AVL<TE,TC> &a) {
    delete raiz;

    if(a.vazia())
        raiz = NULL;
    else
        raiz = new NodoAVL<TE,TC> (a.raiz->chave, a.raiz->elem, a.raiz->bal,a.raiz->esq, a.raiz->dir);

    return *this;
}

template <class TE, class TC>
void AVL<TE,TC>::imp_forma(int k) const {
    for(int i = 0; i < k; ++i)
        cout << ' ';

    if(! raiz) {
        cout << "-" << endl;
        return;
    }

    cout << *(raiz->pelem) << " # " << raiz->bal << endl;

    if(!raiz->esq.vazia() || !raiz->dir.vazia()) {
        raiz->esq.imp_forma(k+2);
        raiz->dir.imp_forma(k+2);
    }
}

#endif
