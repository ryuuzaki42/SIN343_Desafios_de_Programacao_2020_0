/////                                               /////
// Testa a implementacao de Arvore Binaria de Pesquisa //
////                                                /////
#include <iostream>
using namespace std;

class Elem {
    friend ostream & operator << (ostream &, const Elem& e);
public:
    Elem(char c='\0', float x=0) {
        ch=c;
        it=x;
    }
    void set(char c, float x) {
        ch=c;
        it=x;
    }
    char chave() const {
        return ch;
    }

private:
    char ch;
    float it;
};

ostream & operator << (ostream & fout, const Elem& e) {
    fout << "<" << e.ch << "," << e.it << ">";
    return fout;
}

int main() {
    Elem *pe;
    AVL<Elem,char> t;

    try {
        pe = new Elem('C',25);
        t.insere(pe->chave(), pe);
        pe = new Elem('F',10);
        t.insere(pe->chave(), pe);
        pe = new Elem('M',5);
        t.insere(pe->chave(), pe);
        pe = new Elem('J',9);
        t.insere(pe->chave(), pe);
        pe = new Elem('V',55);
        t.insere(pe->chave(), pe);
        pe = new Elem('B',3);
        t.insere(pe->chave(), pe);
        pe = new Elem('P',1);
        t.insere(pe->chave(), pe);
        pe = new Elem('K',13);
        t.insere(pe->chave(), pe);
        pe = new Elem('H',29);
        t.insere(pe->chave(), pe);
        pe = new Elem('L',45);
        t.insere(pe->chave(), pe);
    } catch(Erro_Arv err1) {
        cout << err1.what() << endl;
    }

    cout << "*** Arvore *** \n";
    cout << t << endl;
    cout << "\n\n--- Estrutura da arvore --- \n";
    t.imp_forma(0);
    return 0;
}

/* ------ RESULTADO ESPERADO ------

*** Arvore ***
<B,3>  <C,25>  <F,10>  <H,29>  <J,9>  <K,13>  <L,45>  <M,5>  <P,1>  <V,55>

--- Estrutura da arvore ---
<J,9> # 0
  <F,10> # -1
    <C,25> # -1
      <B,3> # 0
      -
    <H,29> # 0
  <M,5> # 0
    <K,13> # 1
      -
      <L,45> # 0
    <V,55> # -1
      <P,1> # 0
      -
-------------------------------------- */
