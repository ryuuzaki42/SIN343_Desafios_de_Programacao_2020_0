
// https://www.urionlinejudge.com.br/judge/pt/problems/view/1152

#include <bits/stdc++.h>

using namespace std;

#define fori(i, n) for ( int i = 0; i < (n); ++i )
#define sz size()
#define all(x) (x).begin(),(x).end()

// Kruskal − O(m log m)
struct edge {
    int s, t;
    int w; // origem, destino, custo
    bool operator<(const edge& e) const {
        return w < e.w;
    }
};

int mst_kruskal(int N, vector< edge > & edges) {
    int u, v, k;
    int result = 0;
    edge e;
    vector<int> pa(N), comp_sz(N, 1);
    fori(i,N) pa[i] = i;
    sort(all(edges));
    //for(int i=0; i<edges.size(); i++)
    //printf("%d -> %d = %d\n", edges[i].s, edges[i].t, edges[i].w);
    k = 0; // numero de arestas da floresta em construcao

    for(int i = 0; i < edges.sz && k < N-1; ++i) {
        e = edges[i];

        for(u = e.s; u != pa[u]; u = pa[u]); // pa[u] = pa[pa[u]];

        for(v = e.t; v != pa[v]; v = pa[v]); // pa[v] = pa[pa[v]];

        if(u == v)
            continue;

        if(comp_sz[u] < comp_sz[v]) {
            pa[u] = v;
            comp_sz[v] += comp_sz[u];
        } else {
            pa[v] = u;
            comp_sz[u] += comp_sz[v];
        }
        result += e.w;
        k++;
    }
    return result;
}

int main() {
    int n, m;
    int i, j;
    scanf("%d %d", &n, &m);

    while(n != 0 && m!=0) {
        int total = 0;
        vector < edge > lista;

        for(i=0; i<m; i++) {
            edge ar;
            scanf("%d %d %d", &ar.s, &ar.t, &ar.w);
            lista.push_back(ar);
            total += ar.w;
        }

        int mst = mst_kruskal(n, lista);
        printf("%d\n", total - mst);
        scanf("%d %d", &n, &m);
    }
    return 0;
}
