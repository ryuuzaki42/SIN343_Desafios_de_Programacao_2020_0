
// https://www.urionlinejudge.com.br/judge/pt/problems/view/1454

#include <bits/stdc++.h>

using namespace std;

#define INF 0x7FFFFFFF
#define MAX 101

void prim(vector < vector<int> > &lista, vector < vector<int> > &matriz, int n, vector < vector<int> > &M) {
    bool* mst = new bool[n];
    int i, j, nos = 0, valor = 0;

    for(i=0; i<n; i++)
        mst[i] = false;

    mst[0] = true;
    nos++;
    while(nos < n) {
        int menor = -1, menorID, menorIDi;

        for(i=0; i<n; i++)
            if(mst[i])
                for(j=0; j<lista[i].size(); j++)
                    if(!mst[ lista[i][j] ])
                        if(menor == -1 || matriz[i][ lista[i][j] ] < menor) {
                            //printf("%d - %d\n",lista[i][j], matriz[i][ lista[i][j] ]);
                            menor = matriz[i][ lista[i][j] ];
                            menorID = lista[i][j];
                            menorIDi = i;
                        }

        //printf("%d: %d\n", menorID, menor);
        M[menorIDi].push_back(menorID);
        M[menorID].push_back(menorIDi);
        valor += menor;
        nos++;
        mst[menorID] = true;
    }
    delete [] mst;
    //return valor;
}

void dijkstra(vector< vector<int> >& lista, vector< vector<int> >& mat, int dist[MAX][MAX], int prev[MAX][MAX]) {
    vector<int> Q;
    int i, v;
    Q.clear();

    for(int s=0; s<lista.size(); s++) {
        for(i=0; i<lista.size(); i++) {
            dist[s][i] = INF;
            prev[s][i] = -1;
            Q.push_back(i);
        }

        dist[s][s] = 0;

        while(!Q.empty()) {
            int min = -1;
            int minID = 0;

            for(i=0; i<Q.size(); i++)
                if(min == -1 || dist[s][ Q[i] ] < min) {
                    min = dist[s][ Q[i] ];
                    minID = i;
                }
            int u = Q[minID];
            Q.erase(Q.begin() + minID);
            int alt = 0;

            for(v=0; v<lista[u].size(); v++) {
                alt = dist[s][u] + mat[u][ lista[u][v] ];

                //printf("%d -> %d = %d\n", u, lista[u][v], alt);
                if(alt < dist[s][ lista[u][v] ]) {
                    dist[s][ lista[u][v] ] = alt;
                    prev[s][ lista[u][v] ] = u;
                }
            }
        }
    }
}

void dijkstra2(vector< vector<int> >& lista, vector< vector<int> >& mat, int dist[MAX][MAX], int prev[MAX][MAX], int s, int t) {
    vector<int> Q;
    int i, v;
    Q.clear();

    //for(int s=0; s<lista.size(); s++){
    for(i=0; i<lista.size(); i++) {
        dist[s][i] = INF;
        prev[s][i] = -1;
        Q.push_back(i);
    }

    dist[s][s] = 0;

    while(!Q.empty()) {
        int min = -1;
        int minID = 0;

        for(i=0; i<Q.size(); i++)
            if(min == -1 || dist[s][ Q[i] ] < min) {
                min = dist[s][ Q[i] ];
                minID = i;
            }

        int u = Q[minID];
        Q.erase(Q.begin() + minID);

        if(u == t)
            return;

        int alt = 0;
        for(v=0; v<lista[u].size(); v++) {
            alt = dist[s][u] + mat[u][ lista[u][v] ];

            //printf("%d -> %d = %d\n", u, lista[u][v], alt);
            if(alt < dist[s][ lista[u][v] ]) {
                dist[s][ lista[u][v] ] = alt;
                prev[s][ lista[u][v] ] = u;
            }
        }
    }
    //}
}

void BFS(vector< vector<int> >& lista, vector< vector<int> >& mat, int dist[MAX][MAX], int prev[MAX][MAX], int s, int t) {
    vector<int> Q;
    int i, v;
    Q.clear();

    for(i=0; i<lista.size(); i++) {
        dist[s][i] = 0;
        prev[s][i] = -1;
    }

    dist[s][s] = 1;
    Q.push_back(s);
    while(!Q.empty()) {
        int u = Q[0];
        Q.erase(Q.begin());

        if(u == t) return;

        for(v=0; v<lista[u].size(); v++) {
            if(!dist[s][ lista[u][v] ]) {
                dist[s][ lista[u][v] ] = 1;
                prev[s][ lista[u][v] ] = u;
                Q.push_back(lista[u][v]);
            }
        }
    }
}

int main() {
    int n, m, k;
    int i, j;
    int ins = 1;

    scanf("%d %d", &n, &m);
    int dist[MAX][MAX];
    int prev[MAX][MAX];
    vector< vector<int> > lista;
    vector< vector<int> > mst;
    vector< vector<int> > mat;

    while(n!=0 && m!=0) {
        lista.clear();
        mat.clear();
        mst.clear();

        for(i=0; i<n; i++) {
            vector<int> aux;
            lista.push_back(aux);
            mst.push_back(aux);

            for(j=0; j<n; j++)
                aux.push_back(0);

            mat.push_back(aux);
        }

        for(i=0; i<m; i++) {
            int u, v, w;
            scanf("%d %d %d", &u, &v, &w);
            u--;
            v--;
            lista[u].push_back(v);
            lista[v].push_back(u);
            mat[u][v] = mat[v][u] = w;
        }

        /*printf("Lista:\n");
        for(i=0; i<lista.size(); i++){
            printf("%d -> ", i);
            for(j = 0; j<lista[i].size(); j++)
                printf("%d ", lista[i][j]);
            printf("\n");
        }

        printf("Matriz:\n");
        for(i=0; i<lista.size(); i++){
            for(j = 0; j<lista.size(); j++)
                printf("%d ", mat[i][j]);
            printf("\n");
        }*/
        prim(lista, mat, n, mst);
        //dijkstra(mst, mat, dist, prev);
        /*printf("MST:\n");
        for(i=0; i<mst.size(); i++){
            printf("%d -> ", i);
            for(j = 0; j<mst[i].size(); j++)
                printf("%d ", mst[i][j]);
            printf("\n");
        }*/
        printf("Instancia %d\n", ins++);
        /*printf("Dist:\n");
        for(i=0; i<lista.size(); i++){
            printf("%d: ", i);
            for(j = 0; j<lista.size(); j++)
                printf("%d ", dist[i][j]);
            printf("\n");
        }

        printf("Prev:\n");
        for(i=0; i<lista.size(); i++){
            printf("%d: ", i);
            for(j = 0; j<lista.size(); j++)
                printf("%d ", prev[i][j]);
            printf("\n");
        }*/
        scanf("%d", &k);
        int o, d;
        for(int z=0; z<k; z++) {
            scanf("%d %d", &o, &d);
            o--;
            d--;
            int max = 0;

            //int min = -1;
            if(o != d) {
                BFS(mst, mat, dist, prev, o, d);

                while(prev[o][d] != -1) {
                    //if(min == -1 || min > mat[ prev[o][d] ][ d ]){
                    //  min = mat[ prev[o][d] ][ d ];
                    //}
                    if(max == 0 || max < mat[ prev[o][d] ][ d ])
                        max = mat[ prev[o][d] ][ d ];

                    d = prev[o][d];
                }
            }
            printf("%d\n", max);//-min);
        }

        printf("\n");
        //for(i=0; i<n; i++)
        //printf("%d ", dist[0][i]);
        scanf("%d %d", &n, &m);
    }
    return 0;
}
