// Algorithm C++ - ordenacao.cpp

#include<iostream>
#include<vector>
#include<algorithm>

using namespace std;

#define N 10

struct elemento {
    char c;
    int num;
};

void imprime(int *vet) {
    cout << "Vetor:\n";
    for(int i=0; i < N; i++)
        cout << vet[i] << " ";
    cout << endl;
}

void imprime2(elemento *Elem) {
    cout << "Elementos:\n";
    for(int i=0; i < N; i++)
        cout << Elem[i].num << "\t" << Elem[i].c << endl;
}

bool compare(int a, int b) {
    return (a > b);
}

bool compareInt(int a, int b) {
    return (a < b);
}

bool compareNum(elemento a, elemento b) {
    return (a.num > b.num);
}

bool compareChar(elemento a, elemento b) {
    return (a.c < b.c);
}

int main() {
    int vet[N];
    int i;
    srand(time(NULL));

    for(i=0; i < N; i++)
        vet[i] = rand() % 100;

    imprime(vet);
    cout << "\nORDENACAO:\n";
    sort(vet, vet+N);
    imprime(vet);

    cout << "\nBUSCA BINARIA (apenas crescente):\n";
    if(binary_search(vet, vet+N, 10))
        cout << "10 encontrado!\n";
    else
        cout << "Nao encontrado!\n";

    cout << "\n\nORDENACAO 2:\n";
    sort(vet, vet+N, compare);
    imprime(vet);

    cout << "\n\nORDENACAO STRUCT:\n";
    elemento    *Elem = new elemento[N];
    for(i = 0; i < N; i++) {
        Elem[i].num = rand() % 100;
        Elem[i].c = rand() % 3 + 97;
    }
    imprime2(Elem);
    sort(Elem, Elem+N, compareNum);
    imprime2(Elem);
    sort(Elem, Elem+N, compareChar);
    imprime2(Elem);

    cout << "\n\nORDENACAO ESTAVEL:\n";
    double mydoubles[] = {3.14, 1.41, 2.72, 4.67, 1.73, 1.32, 1.62, 2.58};
    vector<double> myvector;
    vector<double>::iterator it;
    myvector.assign(mydoubles,mydoubles+8);
    cout << "Vector:";
    for(it = myvector.begin(); it != myvector.end(); it++)
        cout << ' ' << *it;
    cout << endl;

    cout << "Comparacao Padrao..\n";
    sort(myvector.begin(), myvector.end());
    cout << "Vector:";
    for(it = myvector.begin(); it != myvector.end(); it++)
        cout << ' ' << *it;
    cout << endl;

    cout << "\nComparacao como inteiros..\n";
    cout << "\nNova Atribuicao:\n";
    myvector.assign(mydoubles,mydoubles+8);
    cout << "Vector:";
    for(it = myvector.begin(); it != myvector.end(); it++)
        cout << ' ' << *it;
    cout << endl;
    sort(myvector.begin(), myvector.end(), compareInt);
    cout << "Vector:";
    for(it = myvector.begin(); it != myvector.end(); it++)
        cout << ' ' << *it;
    cout << endl;

    cout << "\n\nNova Atribuicao:\n";
    myvector.assign(mydoubles,mydoubles+8);
    cout << "Vector:";
    for(it = myvector.begin(); it != myvector.end(); it++)
        cout << ' ' << *it;
    cout << endl;
    stable_sort(myvector.begin(), myvector.end(), compareInt);
    cout << "Vector:";
    for(it = myvector.begin(); it != myvector.end(); it++)
        cout << ' ' << *it;
    cout << endl;
    delete [] Elem;
    return 0;
}
