// Algorithm C++ - modificam.cpp

#include<iostream>
#include<vector>
#include<algorithm>

using namespace std;

int main() {
    int inteiros[] = {10,20,30,30,20,10,10,20};
    vector<int> myvector(inteiros, inteiros + 8);
    vector<int>::iterator it, it2;

    cout << "Vector:";
    for(it = myvector.begin(); it != myvector.end(); it++)
        cout << ' ' << *it;
    cout << endl;

    cout << "\n\nREPLACE 20 with 99\n";
    replace(myvector.begin(), myvector.end(), 20, 99);

    cout << "Vector:";
    for(it=myvector.begin(); it!=myvector.end(); ++it)
        cout << ' ' << *it;
    cout << endl;

    cout << "\n\nREMOVE 99\n";
    it2 = remove(myvector.begin(), myvector.end(), 99);

    cout << "Vector:";
    for(it=myvector.begin(); it!=it2; ++it)
        cout << ' ' << *it;
    cout << endl;

    cout << "\n\nROTATE: vector.begin with vector.begin + 3\n";
    myvector.clear();
    for(int i = 1; i < 10; ++i)
        myvector.push_back(i); // 1 2 3 4 5 6 7 8 9
    cout << "Vector:";
    for(it = myvector.begin(); it != myvector.end(); ++it)
        cout << ' ' << *it;
    cout << endl;

    rotate(myvector.begin(), myvector.begin() + 3, myvector.end());
    cout << "Vector:";
    for(it=myvector.begin(); it!=myvector.end(); ++it)
        cout << ' ' << *it;
    cout << endl;
    return 0;
}
