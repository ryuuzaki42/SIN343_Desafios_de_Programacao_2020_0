// Algorithm C++ -  naoModificam.cpp

#include<iostream>
#include<vector>
#include<algorithm>

using namespace std;

int main() {
    int inteiros[] = { 20, 30, 40 };
    int *p, i;

    cout << "Inteiros: ";
    for(i=0; i<3; i++) cout << inteiros[i] << " ";
    cout << endl;

    vector<int> myvector;
    vector<int>::iterator it;

    for(i=1; i<10; i++)
        myvector.push_back(i*10);

    cout << "Vector: ";
    for(i = 0; i < 9; i++)
        cout << myvector[i] << " ";
    cout << endl;

    cout << "\nFIND:\n";
    // using find with array and pointer:
    p = find(inteiros, inteiros+3, 30);

    if(p != inteiros+3)
        cout << "Elemento encontrado: " << *p << '\n';
    else
        cout << "Elemento nao encontrado!\n";

    // using find with vector and iterator:
    it = find(myvector.begin(), myvector.end(), 30);
    if(it != myvector.end())
        cout << "[Vector] Elemento encontrado: " << *it << '\n';
    else
        cout << "[Vector] Elemento nao encontrado!\n";

    cout << "\n\nSEARCH:\n";
    it = search(myvector.begin(), myvector.end(), inteiros, inteiros+3);
    if(it!=myvector.end())
        cout << "[Vector] Intervalo encontrado na posicao: " << (it - myvector.begin()) << '\n';
    else
        cout << "[Vector] Intervalo nao encontrado!\n";

    cout << "\n\nCOUNT:\n";
    int inteiros2[] = {10,20,30,30,20,10,10,20};
    cout << "Inteiros2: ";
    for(i = 0; i < 8; i++)
        cout << inteiros2[i] << " ";
    cout << endl;

    int mycount = count(inteiros2, inteiros2+8, 10);
    cout << "10 aparece " << mycount << " vezes.\n";

    // counting elements in container:
    vector<int> myvector2(inteiros2, inteiros2+8);
    mycount = count(myvector2.begin(), myvector2.end(), 20);
    cout << "[Vector] 20 aparece " << mycount  << " vezes.\n";
    return 0;
}
