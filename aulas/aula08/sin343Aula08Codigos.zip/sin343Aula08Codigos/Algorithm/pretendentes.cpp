// Algorithm C++ - pretendentes.cpp

// #include<iostream>
#include<stdio.h>
#include<vector>
#include<string.h>
#include<algorithm>

using namespace std;

struct pretendente {
    int id;
    char nome[50];
    char sobre[50];
    int altura;
    int peso;
};

#define ALTURA 180
#define PESO 75

bool compare(pretendente a, pretendente b) {
    if(a.altura < b.altura)
        return true;

    if(a.altura > b.altura)
        return false;

    if(a.peso < b.peso)
        return true;

    if(a.peso > b.peso)
        return false;

    int v = strcmp(a.sobre, b.sobre);

    if(v < 0)
        return true;

    if(v > 0)
        return false;

    v = strcmp(a.nome, b.nome);

    if(v < 0)
        return true;

    if(v > 0)
        return false;

    return false;
}

int main() {
    vector<pretendente> vetor;
    vector<pretendente>::iterator it;
    int a = 0;
    pretendente p;

    while(scanf("%s %s %d %d", p.nome, p.sobre, &p.altura, &p.peso) != EOF) {
        p.id = a;
        p.altura = abs(p.altura - ALTURA);

        if(p.peso > PESO)
            p.peso = p.peso - PESO;
        else
            p.peso = (-p.peso);

        vetor.push_back(p);
        a++;
    }

    for(it = vetor.begin(); it != vetor.end(); it++)
        printf("%s %s %d %d\n", it->nome, it->sobre, it->altura, it->peso);

    sort(vetor.begin(), vetor.end(), compare);

    printf("\nSaida:\n");
    for(it = vetor.begin(); it != vetor.end(); it++)
        printf("%d: %s, %s\n", it->id, it->sobre, it->nome);

    return 0;
}
