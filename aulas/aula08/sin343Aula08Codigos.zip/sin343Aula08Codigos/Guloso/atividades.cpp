// Algoritmo Guloso - atividades.cpp

#include<iostream>
#include<algorithm>

using namespace std;

struct tarefa {
    int id;
    int s, t;//Tempos inicio e fim
};

bool compare(tarefa a, tarefa b) {
    return (a.t < b.t);
}

void Atividades(tarefa *A, int *S, int n, int &T) {
    int i, j, k;
    T = 0;

    for(i=0; i<n; i++)
        S[i] = 0;

    sort(A, A+n, compare); //Ordena A pelo tempo de termino
    i = 0;
    k = 0;
    S[i] = A[i].id; // Atividade 1
    i++;
    T = i;

    for(j = 1; j < n; j++)
        if(A[j].s >= A[k].t) {
            S[i] = A[j].id;
            i++;
            T = i;
            k = j;
        }
}

int main() {
    int n, T, i;
    cin >> n;
    tarefa *A = new tarefa[n];
    int* sol = new int[n]; // solucao

    for(i=0; i<n; i++) {
        A[i].id = i+1;
        cin >> A[i].s;
    }

    for(i=0; i<n; i++)
        cin >> A[i].t;

    Atividades(A, sol, n, T);
    cout << "Total de Atividades: " << T << endl;

    for(i=0; i<T; i++)
        cout << sol[i] << " ";
    cout << endl;
    delete [] A;
    delete [] sol;
    return 0;
}
