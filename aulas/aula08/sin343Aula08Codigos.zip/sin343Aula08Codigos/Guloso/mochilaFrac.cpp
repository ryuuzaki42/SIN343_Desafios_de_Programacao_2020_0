// Algoritmo Guloso - mochilaFrac.cpp

#include<iostream>
#include<algorithm>

using namespace std;

struct item {
    int id;
    double peso, custo, cb;//Custo beneficio
};

bool compare(item a, item b) {
    return (a.cb >= b.cb);
}

void guloso(item *vet, double *S, int W, int n, double &T) {
    int i;
    T = 0;

    for(i=0; i<n; i++)
        S[i] = 0;

    sort(vet, vet+n, compare); // Ordena pelo maior custo beneficio
//     for(i=0; i<n; i++)
//         cout << vet[i].peso << " " << vet[i].custo << " " << vet[i].cb << endl;

    i=0;
    while(i < n && vet[i].peso < W) {
        S[vet[i].id] = 1;
        T += (S[vet[i].id]*vet[i].custo);
        W -= vet[i].peso;
        i++;
    }

    if(i < n) {
        S[vet[i].id] = W / vet[i].peso;
        T += (S[vet[i].id]*vet[i].custo);
    }
}

int main() {
    int n, W, i;
    double T;
    cin >> n >> W;
    item *itens = new item[n];
    double* sol = new double[n]; // solucao

    for(i = 0; i < n; i++) {
        itens[i].id = i;
        cin >> itens[i].peso;
        cin >> itens[i].custo;
        itens[i].cb = (itens[i].custo/itens[i].peso);
    }

    for(i = 0; i < n; i++)
        cout << itens[i].id << ": " << itens[i].peso << " " << itens[i].custo << " " << itens[i].cb << endl;
    cout << endl;

    guloso(itens, sol, W, n, T);
    cout << "Custo total: " << T << endl;
    for(i=0; i<n; i++)
        cout << i << ": " << sol[i] << endl;

    delete [] itens;
    delete [] sol;
    return 0;
}
