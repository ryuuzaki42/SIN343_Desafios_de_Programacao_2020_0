#include<iostream>
#include<stdlib.h>

using namespace std;

void Merge(int L[], int ini, int meio, int fim) {
    int *A = new int [fim - ini +1]; //vetor auxiliar
    int i = ini, j = meio+1, k = 0;

    while(i<=meio && j<=fim) {
        if(L[i] < L[j]) {
            A[k] =L[i];
            i++;
        } else {
            A[k] =L[j];
            j++;
        }

        k++;
    }

    while(i<=meio) {
        A[k] =L[i];
        i++;
        k++;
    }

    while(j<=fim) {
        A[k] =L[j];
        j++;
        k++;
    }

    for(i = ini, k=0; i<=fim; i++, k++)
        L[i] = A[k];

    delete [] A;
}

void MergeSort(int L[], int ini, int fim) {
    if(ini < fim) {
        int meio = (ini + fim)/2;
        MergeSort(L, ini, meio);
        MergeSort(L, meio+1, fim);
        Merge(L, ini, meio, fim);
    }
}

int main() {
    int n;
    cin >> n;
    int *a = new int[n];
    int i;

    for(i=0; i<n; i++)
        a[i] = rand()%100;

    cout << "Antes\n";

    for(i=0; i<n; i++)
        cout << a[i] << " ";

    cout << endl;
    MergeSort(a, 0, n-1);
    cout << "\n\nDepois\n";

    for(i=0; i<n; i++)
        cout << a[i] << " ";

    cout << endl;
    delete [] a;
    return 0;
}
