// Algoritmo Busca Binaria Recursivo

#include<stdio.h>
#include<stdlib.h>

int rec_buscaBin(int * v, int x, int inicio, int fim) {
    if(inicio > fim) // 1o caso base
        return -1;

    int meio = (inicio + fim)/2;
    if(x == v[meio]) // 2o caso base
        return meio;
    else if(x > v[meio])
        return rec_buscaBin(v, x, meio + 1, fim);
    else
        return rec_buscaBin(v, x, inicio, meio-1);
}

int it_buscaBin(int * v, int x, int inicio, int fim) {
    int meio;

    while(inicio <= fim) {
        meio = (inicio + fim)/2;

        if(x == v[meio])
            return meio; // encontrou elemento
        else if(x > v[meio]) // eliminando metade das possibilidades
            inicio = meio+1;
        else
            fim = meio - 1;
    }
    return -1; // se nao encontrar retorna -1
}

int main() {
    int n = 15, i;
    int *v = (int*) malloc(n * sizeof(int));
    v[0] = 1;
    v[1] = 2;

    for(i = 2; i < n; i++)
        v[i] = v[i-2] + v[i-1];

    printf("v = {");
    for(i = 0; i < n - 1; i++)
        printf("%d, ", v[i]);
    printf("%d}\n", v[n-1]);

    int x;
    printf("\nDigite um numero para buscar:\n");
    scanf("%d",&x);

    printf("-------RECURSIVO--------\n");
    int pos = rec_buscaBin(v, x, 0, n);
    if(pos != -1)
        printf("O numero %d esta na posicao %d.\n", x, pos);
    else
        printf("O numero %d nao esta no vetor!\n", x);

    printf("---------------------------------------\n");

    printf("-------ITERATIVO--------\n");
    pos = it_buscaBin(v, x, 0, n);
    if(pos != -1)
        printf("O numero %d esta na posicao %d.\n", x, pos);
    else
        printf("O numero %d nao esta no vetor!\n", x);

    free(v);
    return 0;
}
