#include <iostream>

using namespace std;

int main() {
    int m, n;
    cin >> m >> n;

    while(m!=0 || n!=0) {
        int r;

        if(n == 0)
            cout << "MDC = " << m << endl;
        else {
            while(n != 0) {
                r = m%n;
                m = n;
                n = r;
            }

            cout << "MDC = " << m << endl;
        }

        cin >> m >> n;
    }

    return 0;
}
