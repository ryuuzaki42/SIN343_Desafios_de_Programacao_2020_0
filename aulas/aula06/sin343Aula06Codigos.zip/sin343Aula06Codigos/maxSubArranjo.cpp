#include<iostream>
#include<stdlib.h>
#include<limits.h>

using namespace std;

class Solucao {
public:
    Solucao() {
        low = high = soma = 0;
    }

    Solucao(int l, int h, int s) {
        low = l;
        high = h;
        soma = s;
    }

    Solucao(const Solucao& s) {
        low = s.low;
        high = s.high;
        soma = s.soma;
    }

    int low, high, soma;
};

Solucao MaxCrossSubArray(int *v, int low, int mid, int high) {
    int maxEsq, maxDir, somaEsq = INT_MIN, somaDir = INT_MIN;
    int soma = 0;

    for(int i = mid; i>= low; i--) {
        soma += v[i];

        if(soma > somaEsq) {
            somaEsq = soma;
            maxEsq = i;
        }
    }

    soma = 0;

    for(int j = mid + 1; j <= high; j++) {
        soma += v[j];

        if(soma > somaDir) {
            somaDir = soma;
            maxDir = j;
        }
    }

    Solucao S(maxEsq, maxDir, somaEsq + somaDir);
    return S;
}

Solucao MaxSubArray(int *v, int low, int high) {
    if(high == low) {
        Solucao S(low, high, v[low]);
        return S;
    } else {
        Solucao SEsq, SDir, SMeio;
        int mid = (low + high)/2;
        SEsq = MaxSubArray(v, low, mid);
        SDir = MaxSubArray(v, mid + 1, high);
        SMeio = MaxCrossSubArray(v, low, mid, high);

        if((SEsq.soma >= SDir.soma) && (SEsq.soma >= SMeio.soma))
            return SEsq;
        else if((SDir.soma >= SEsq.soma) && (SDir.soma >= SMeio.soma))
            return SDir;
        else
            return SMeio;
    }
}

int main() {
    int n;
    cin >> n;
    int *a = new int[n];
    int i;

    for(i = 0; i < n; i++)
        cin >> a[i];

    for(i = 0; i < n; i++)
        cout << a[i] << " ";

    cout << endl;
    Solucao s = MaxSubArray(a, 0, n-1);
    cout << s.low + 1 << " - " << s.high + 1 << " = " << s.soma << endl;
    delete [] a;
    return 0;
}
