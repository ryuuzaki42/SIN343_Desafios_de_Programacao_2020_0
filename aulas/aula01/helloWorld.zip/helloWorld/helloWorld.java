public class helloWorld {
    public static void main(String[] args){
        System.out.println("Hello World");
    }
}

// sudo su
// 123456

// apt-get install default-jdk
