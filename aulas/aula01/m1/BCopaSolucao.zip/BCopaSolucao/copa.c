#include <stdio.h>

int main() {
    char temp[10000];
    int points, soma, empates;
    int a, b, i;
    soma = 0;

    scanf("%d", &a);
    scanf("%d", &b);

    for(i = 0; i < a; i++) {
        scanf("%s%d",temp, &points);
        soma += points;
    }

    empates = ((3 * b) - soma);
    printf("%d\n", empates);
    return 0;
}
