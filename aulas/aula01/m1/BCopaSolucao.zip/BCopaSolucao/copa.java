import java.util.Scanner;

public class copa {
    public static void main(String[] args) {
        int T, N, soma;
        String frase;

        Scanner s = new Scanner(System.in);
        T = s.nextInt();
        N = s.nextInt();
        soma = 0;

        String textoSeparado[] = new String[2];
        int i, empates;
        frase = s.nextLine();
//         System.out.println("Frase: " + frase);

        for(i = 0; i < T; i++) {
            frase = s.nextLine();
//             System.out.println("Frase: " + frase);
            textoSeparado = frase.split(" ");
            soma += Integer.parseInt(textoSeparado[1]);
//             System.out.println(Integer.parseInt(textoSeparado[1]));
        }

        empates = ((3 * N) - soma);
        System.out.println(empates);
    }
}
