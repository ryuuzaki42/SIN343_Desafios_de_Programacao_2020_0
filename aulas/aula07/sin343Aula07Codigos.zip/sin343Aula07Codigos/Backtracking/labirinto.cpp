// Algoritmo Backtracking Labirinto
// Espera um arquivo de entrada do labirinto.txt

#include <iostream>
#include <fstream>
#define MAX 100
using namespace std;

char mapa[MAX][MAX];
bool achei;

//imprime a situacao atual
void imprime(int nl, int nc) {
    for(int i=0; i<nl; i++) {
        for(int j=0; j<nc; j++)
            cout << mapa[i][j];
        cout << endl;
    }
    cin.get();  //espera apertar 'enter'
}

//caminha no labirinto (por backtracking)
void caminha(int i, int j, int nl, int nc) {
    if(achei)   //permite sair das chamadas recursivas empilhadas
        return;

    if(mapa[i][j] != '.')     //nao posso andar por aqui
        return;

    // se chegou na borda do labirinto
    if(i == 0 || j == 0 || i == nl-1 || j == nc-1) {
        mapa[i][j] = 's';
        achei = true;   //consegui achar a saida
        return;
    }

    //se nao retornou ainda, e' porque posso continuar caminhando
    mapa[i][j] = 'o';   //marca que ja passei por aqui
    imprime(nl, nc);
    caminha(i+1, j, nl, nc);   //caminha para baixo
    caminha(i-1, j, nl, nc);   //caminha para cima
    caminha(i, j-1, nl, nc);   //caminha para esquerda
    caminha(i, j+1, nl, nc);   //caminha para direita

    //se nenhum caminho deu certo entao volta
    if(!achei) {
        mapa[i][j] = '-';  //desmarca posicao
        cout << "Voltei...\n\n";
    }
}

int main() {
    int i, j, nl, nc;
    int inil, inic;
    char arquivo[50];
    cout << "Nome do arquivo:\n";
    cin >> arquivo;
    //cout << arquivo << endl;
    //ifstream ent(arquivo, ios:in);
    ifstream arq; // contém lista de valores em °F
    arq.open(arquivo);  // abrir arquivo
    cout << "Tamanho do mapa: ";
    arq >> nl >> nc;
    cout << "Desenho do mapa:\n";

    for(i = 0; i < nl; i++)
        for(j = 0; j < nc; j++) {
            mapa[i][j] = arq.get();

            if(mapa[i][j] == '\n')
                j--;
        }

    cout << "Posicao inicial: ";
    arq >> inil >> inic;
    //cout << inil << inic << endl;
    cin.get();  //le o 'enter'
    achei = false;
    caminha(inil, inic, nl, nc);

    if(!achei)
        cout << "Sem saida!\n";
    else {
        cout << "--Solucao:--\n\n";
        imprime(nl, nc);
    }

    arq.close();
    return 0;
}
