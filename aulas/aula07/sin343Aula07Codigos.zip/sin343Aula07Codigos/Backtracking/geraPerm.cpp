#include<iostream>

using namespace std;

bool pertence(int a[], int n, int k) {
    for(int i = 0; i < n; i++)
        if(a[i] == k)
            return true;

    return false;
}

void imprimePerm(int a[], int n) {
    for(int i = 0; i < n; i++)
        cout << a[i] << " ";
    cout << endl;
}

void geraPerm(int a[], int k, int n) {
    if(k == n) { // se terminou de gerar a permutação
        imprimePerm(a, n);
        return;
    }

    for(int i = 1; i <= n; i++) { // para todo elemento i
        if(!pertence(a, k, i)) { // se i não está na permutação parcial
            a[k] = i; // inclui o elemento na permutação
            geraPerm(a, k+1, n); // gera o restante da permutação
        }
    }
}

int main() {
    int a[1000]; // permutação parcial
    int n; // tamanho do conjunto
    cin >> n;
    geraPerm(a, 0, n); // permutações de {1, 2, 3, ..., n}
    return 0;
}
