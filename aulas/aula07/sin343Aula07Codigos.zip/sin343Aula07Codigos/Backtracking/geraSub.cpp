#include<iostream>

using namespace std;

void imprimeSub(bool a[], int n) {
    cout << "{";
    for(int i = 0; i < n; i++) {
        if(a[i])
            cout << " " << i+1;
    }
    cout << " }" << endl;
}

void geraSub(bool a[], int k, int n) {
    if(k == n) { // se terminou de gerar um subconjunto
        imprimeSub(a, n);
        return;
    }

    a[k] = true; // subconjuntos com o elemento k
    geraSub(a, k + 1, n);
    a[k] = false;
    geraSub(a, k + 1, n); // subconjuntos sem o elemento k
}

int main() {
    bool a[1000]; // subconjunto parcial
    int n; // tamanho do conjunto
    cin >> n;
    geraSub(a, 0, n); // subconjuntos de {1, 2, 3, ..., n}
    return 0;
}
