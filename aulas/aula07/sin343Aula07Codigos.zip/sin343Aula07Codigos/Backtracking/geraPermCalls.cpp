#include<iostream>

using namespace std;

int call = 0;

bool pertence(int a[], int n, int k) {
    for(int i = 0; i < n; i++)
        if(a[i] == k)
            return true;

    return false;
}

void imprimePerm(int a[], int n) {
    for(int i = 0; i < n; i++)
        cout << a[i] << " ";
    cout << endl;
}

void geraPerm(int a[], int k, int n) {

    call++;
    for(int j = 0; j < k; j++)
        cout << "       ";
    cout << "geraPerm(int a[], " << k << ", " << n << ")" <<" call: "<< call <<  endl;

    if(k == n) { // se terminou de gerar a permutação
        imprimePerm(a, n);
        return;
    }

    for(int i = 1; i <= n; i++) { // para todo elemento i

        for(int j = 0; j <= k; j++)
            cout << "       ";
        cout << "for i: " << i << " n: " << n << endl;

        if(!pertence(a, k, i)) { // se i não está na permutação parcial
            a[k] = i; // inclui o elemento na permutação

            for(int j = 0; j <= k; j++)
                cout << "       ";
            cout << "k: " << k << " n: " << n << " vet a[i]: " ;
            for(int j = 0; j < n; j++)
                cout << a[j] << " ";
            cout << endl;

            geraPerm(a, k + 1, n); // gera o restante da permutação
        }
    }
}

int main() {
    int a[1000]; // permutação parcial
    int n; // tamanho do conjunto
    cin >> n;
    geraPerm(a, 0, n); // permutações de {1, 2, 3, ..., n}
    return 0;
}
