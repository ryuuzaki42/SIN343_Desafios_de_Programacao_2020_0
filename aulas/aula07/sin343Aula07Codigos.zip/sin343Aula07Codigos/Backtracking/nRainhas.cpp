// Algoritmo Backtracking N Rainhas

#include<iostream>
#include<cmath>

using namespace std;

int possibilidades = 0;
int movimentos = 0;
bool achei = false;

void imprimeTabuleiro(int *Q, int n) {
    cout << "\nSolucao:\n";
    for(int i=0; i<n; i++) {
        for(int j=0; j < n; j++)
            if(Q[i] == j) cout << "Q ";
            else cout << "- ";
        cout << endl;
    }
}

bool verifica(int *Q, int C, int k) {
    for(int i = 0; i < k; i++) {
        if(Q[i] == C)
            return false; //Rainha na mesma Coluna

        if(abs(i - k) == abs(Q[i] - C))
            return false;   //Rainha na mesma Diagonal
    }
    return true;
}

void backtrack(int *Q, int k, int n) {
    if(achei)
        return;

    movimentos++;
    if(k == n) { //Achei uma solucao
        imprimeTabuleiro(Q, n);
        possibilidades++;
        //achei = true;
        return;
    }

    for(int col = 0; col < n; col++) { // Tenho n colunas para colocar a rainha K
        if(verifica(Q, col, k)) {
            Q[k] = col;
            backtrack(Q, k + 1, n);
        }
    }
}

int main() {
    int n; // Num. de Rainhas
    cout << "Quantas Rainhas?\n";
    cin >> n;
    int *Q = new int[n]; // subconjunto parcial
    backtrack(Q, 0, n); // subconjuntos de {1, 2, 3, ..., n}
    cout << "Possibilidades: " << possibilidades << endl;
    cout << "Movimentos: " << movimentos-1 << endl;
    delete [] Q;
    return 0;
}
