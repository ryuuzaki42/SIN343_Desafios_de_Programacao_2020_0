#include<iostream>

using namespace std;

int possibilidades = 0;

void imprimesub(bool a[], int n) {
    int i;
    cout << "{";
    for(i = 0; i < n; i++) {
        if(a[i])
            cout << " " << i+1;
    }
    cout << " }" << endl;
}

void imprimesub(int S[], bool a[], int n) {
    int i;
    cout << "{";
    for(i = 0; i < n; i++) {
        if(a[i])
            cout << " " << S[i];
    }
    cout << " }" << endl;
}

bool achei = false;

void gerasub(bool a[], int k, int n, int S[], int soma, int m) {
    if(achei)
        return;

    if(soma == m) {
        imprimesub(S, a, n);
        achei = true;
        //return;
    }

    if(k == n) { // se terminou de gerar um subconjunto
        //imprimesub(a, n);
        possibilidades++;
        return;
    }

    //if(soma < m){ //Branch and Bound
    a[k] = true;// subconjuntos com o elemento k
    gerasub(a, k + 1, n, S, soma+S[k], m);
    a[k] = false;// subconjuntos sem o elemento k
    gerasub(a, k + 1, n, S, soma, m);
    //}
}

int main() {
    bool a[1000]; // subconjunto parcial
    int m = 15; // soma buscada no subconjunto
    int n = 6; // tamanho do conjunto
    int S[6] = {3, 5, 6, 7, 3, 9};
    gerasub(a, 0, n, S, 0, m); // subconjuntos de {1, 2, 3, ..., n}
    cout << "Possibilidades: " << possibilidades << endl;
    return 0;
}
