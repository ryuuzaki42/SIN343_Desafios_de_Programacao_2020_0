// Problema da Mochila - Recursivo e Programacao Dinamica

#include<iostream>
#include<stdio.h>
#include<stdlib.h>
#include<limits.h>
#include<time.h>

using namespace std;

int max(int a, int b) {
    return (a > b ? a : b);
}

//Recursivo
int mochila01Recursivo(int *v, int *p, int n, int W) {
    if(n == 0 || W <= 0) // se não há itens ou não cabe nada
        //C[i][j] = 0
        return 0;
    else if(p[n] > W) // se item i não cabe nessa mochila
        //C[i][j] = C[i-1][j]
        return mochila01Recursivo(v, p, n-1, W); // considera somente os itens anteriores
    else if(p[n] <= W) {
        int semItem = mochila01Recursivo(v, p, n-1, W); // mochila sem o item
        int comItem = mochila01Recursivo(v, p, n-1, W - p[n]) + v[n]; // mochila com o item
        //C[i][j] = max { C[i-1][j], C[i-1][j-wi] + vi }
        return max(semItem, comItem);
    }
}

//Programacao Dinamica
int mochila01PD(int *v, int *p, int n, int W, int **V, int** itens) {
    int i, j;
    for(i = 0; i <= n; i++) {
        V[i][0] = 0; // mochila sem capacidade
        itens[i][0] = 0;
    }

    for(j = 0; j <= W; j++) {
        V[0][j] = 0; // mochila sem itens
        itens[0][j] = 0;
    }

    for(i = 1; i <= n; i++)
        for(j = 1; j <= W; j++)
            if(p[i] > j) { //se nao cabe
                V[i][j] = V[i-1][j]; //mochila sem ele
                itens[i][j] = 0;
            } else { // se cabe e o maximo da mochila com o item ou sem o item
                int semItem = V[i-1][j]; // mochila sem o item
                int comItem = V[i-1][j - p[i]] + v[i]; // mochila com o item

                //V[i][j] = max(semItem,comItem);
                if(comItem > semItem) {
                    V[i][j] = comItem;
                    itens[i][j] = 1;
                } else {
                    V[i][j] = semItem;
                    itens[i][j] = 0;
                }
            }

    return V[n][W];
}

int main() {
    int n, i, W;
    clock_t rec, pd;

    cin >> n >> W;
    int *valor = new int[n+1];
    int *peso = new int[n+1];

    for(i = 1; i <= n; i++)
        cin >> valor[i];

    for(i = 1; i <= n; i++)
        cin >> peso[i];

    //Recursivo
    rec = clock();
    int valorMaxRec = mochila01Recursivo(valor, peso, n, W);
    rec = clock() - rec;

    //Alocacao
    int **V = new int*[n+1];
    for(i = 0; i <= n; i++)
        V[i] = new int[W+1];

    int **itens = new int*[n+1];
    for(i = 0; i <= n; i++)
        itens[i] = new int[W+1];

    //PD
    pd = clock();
    int valorMaxPD = mochila01PD(valor, peso, n, W, V, itens);
    pd = clock() - pd;
    cout << "Lista de Itens: ";

    for(i = n; i >= 1; i--)
        if(itens[i][W] == 1) {
            cout << i << " ";
            W = W - peso[i];
        }

    cout << endl;
    printf("Recursivo\n");
    printf("Valor: %d | %.10f segundos\n\n", valorMaxRec, ((float)rec)/CLOCKS_PER_SEC);
    printf("Programacao Dinamica\n");
    printf("Valor: %d | %.10f segundos\n\n", valorMaxPD, ((float)pd)/CLOCKS_PER_SEC);

    //Desaloca
    delete [] valor;
    delete [] peso;

    for(i = 0; i <= n; i++)
        delete [] V[i];
    delete [] V;

    for(i = 0; i <= n; i++)
        delete [] itens[i];
    delete [] itens;
    return 0;
}
