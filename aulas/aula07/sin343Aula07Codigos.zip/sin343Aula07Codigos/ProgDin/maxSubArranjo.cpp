// Fibonacci Programacao Dinamica

#include<iostream>
#include<stdio.h>
#include<stdlib.h>
#include<limits.h>
#include<time.h>

using namespace std;

class Solucao {

public:
    Solucao() {
        low = high = soma = 0;
    }

    Solucao(int l, int h, int s) {
        low = l;
        high = h;
        soma = s;
    }

    Solucao(const Solucao& s) {
        low = s.low;
        high = s.high;
        soma = s.soma;
    }

    int low, high, soma;
};

//Forca Bruta
Solucao forcaBruta(int *v, int low, int high) {
    int i, j, k;
    int maxEsq=0, maxDir=0, somaMax = v[low];

    for(i=low; i<=high; i++) {
        int soma = 0;

        for(j=i; j<=high; j++) {
            soma+=v[j];

            if(soma > somaMax) {
                somaMax = soma;
                maxEsq = i;
                maxDir = j;
            }
        }
    }

    Solucao S(maxEsq, maxDir, somaMax);
    return S;
}

Solucao MaxCrossSubArray(int *v, int low, int mid, int high) {
    int maxEsq, maxDir, somaEsq = INT_MIN, somaDir = INT_MIN;
    int soma = 0;

    for(int i = mid; i>= low; i--) {
        soma += v[i];

        if(soma > somaEsq) {
            somaEsq = soma;
            maxEsq = i;
        }
    }

    soma = 0;

    for(int j = mid+1; j <= high; j++) {
        soma += v[j];

        if(soma > somaDir) {
            somaDir = soma;
            maxDir = j;
        }
    }

    Solucao S(maxEsq, maxDir, somaEsq+somaDir);
    return S;
}

//Divisao e Conquista
Solucao MaxSubArray(int *v, int low, int high) {
    if(high == low) {
        Solucao S(low, high, v[low]);
        return S;
    } else {
        Solucao SEsq, SDir, SMeio;
        int mid = (low+high)/2;
        SEsq = MaxSubArray(v, low, mid);
        SDir = MaxSubArray(v, mid+1, high);
        SMeio = MaxCrossSubArray(v, low, mid, high);

        if(SEsq.soma >= SDir.soma && SEsq.soma >= SMeio.soma)
            return SEsq;
        else if(SDir.soma >= SEsq.soma && SDir.soma >= SMeio.soma)
            return SDir;
        else
            return SMeio;
    }
}

//Programacao Dinamica
Solucao ProgDin(int *v, int *T, int low, int high) {
    int i, maxEsq = 0, maxDir = 0, recomeco = 0, somaMax;
    T[low] = v[low];
    somaMax = T[low];

    for(i = low+1; i <= high; i++) {
        if(T[i - 1] > 0) {
            T[i] = T[i - 1] + v[i];

            if(T[i] > somaMax) {
                somaMax = T[i];
                maxEsq = recomeco;
                maxDir = i;
            }
        } else {
            T[i] = v[i];
            recomeco = i;

            if(T[i] > somaMax) {
                somaMax = T[i];
                maxEsq = recomeco;
                maxDir = i;
            }
        }
    }

    Solucao S(maxEsq, maxDir, somaMax);
    return S;
}

int main() {
    int n, i;
    clock_t fb, dc, pd;
    cin >> n;
    int *a = new int[n];
    int num, num2;
    srand(time(NULL));

    for(i=0; i<n; i++) {
        //num = rand()%2;
        //num2 = rand()%100;
        //a[i] = ( num ? num2 : -num2 );
        cin >> a[i];
    }
    for(i=0; i<n; i++)
        cout << a[i] << " ";
    cout << endl;

    //FB
    fb = clock();
    Solucao sfb = forcaBruta(a, 0, n-1);
    fb = clock() - fb;

    //DC
    dc = clock();
    Solucao sdc = MaxSubArray(a, 0, n-1);
    dc = clock() - dc;
    int *tab = new int[n];

    //PD
    pd = clock();
    Solucao spd = ProgDin(a, tab, 0, n-1);
    pd = clock() - pd;

    printf("Forca Bruta\n");
    printf("%d - %d = %d | %.10f segundos\n\n", sfb.low+1, sfb.high+1, sfb.soma, ((float)fb)/CLOCKS_PER_SEC);
    printf("Divisao e Conquista\n");
    printf("%d - %d = %d | %.10f segundos\n\n", sdc.low+1, sdc.high+1, sdc.soma, ((float)dc)/CLOCKS_PER_SEC);
    printf("Programacao Dinamica\n");
    printf("%d - %d = %d | %.10f segundos\n\n", spd.low+1, spd.high+1, spd.soma, ((float)pd)/CLOCKS_PER_SEC);

    delete [] a;
    delete [] tab;
    return 0;
}
