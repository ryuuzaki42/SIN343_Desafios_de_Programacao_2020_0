// Fibonacci Programacao Dinamica

#include <stdio.h>
#include <time.h>

using namespace std;

#define MAX 100

int tab[100] = {0, 1};

int fibo_sem_PD(int n) {
    if(n <= 1)
        return n;

    return (fibo_sem_PD(n-2) + fibo_sem_PD(n-1));
}

int fibo_Top_Down(int n) {
    if(tab[n]==-1)
        tab[n] = fibo_Top_Down(n-1) + fibo_Top_Down(n-2);

    return tab[n];
}

int fibo_Bottom_Up(int n) {
    tab[0] = 0;
    tab[1] = 1;

    for(int i=2; i<=n; i++)
        tab[n] = tab[n-1] + tab[n-2];

    return tab[n];
}

int main() {
    int n, i, tr, ttd, tbu;
    clock_t rec, td, bu;
    printf("Digite o termo desejado da serie de fibonacci:\n");
    scanf("%d", &n);

    for(i = 0; i<=n; i++) // 0, 1, -1, -1, -1, ...
        (i <= 1 ? tab[i] = i: tab[i] = -1);

    //Tempo fibo_sem_PD
    rec = clock();
    tr = fibo_sem_PD(n);
    rec = clock() - rec;
    //Tempo Top-Down
    td = clock();
    ttd = fibo_Top_Down(n);
    td = clock() - td;
    //Tempo Bottom-Up
    bu = clock();
    tbu = fibo_Bottom_Up(n);
    bu = clock() - bu;
    printf("--------------RESPOSTA-----------------\n");
    printf("Sem Programacao Dinamica\n");
    printf("Termo: %d - %.10f segundos\n\n", tr, ((float)rec)/CLOCKS_PER_SEC);
    printf("Top Down\n");
    printf("Termo: %d - %.10f segundos\n\n", ttd, ((float)td)/CLOCKS_PER_SEC);
    printf("Bottom Up\n");
    printf("Termo: %d - %.10f segundos\n\n", tbu, ((float)bu)/CLOCKS_PER_SEC);
    return 0;
}
