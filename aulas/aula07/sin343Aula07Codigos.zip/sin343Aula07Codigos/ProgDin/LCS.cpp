// Longest Common Subsequence (LCS) Recursivo e Programacao Dinamica

#include<iostream>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<limits.h>
#include<time.h>
using namespace std;

int max(int a, int b) {
    return (a>b ? a : b);
}

//Recursivo
int LCSRecursivo(char *x, char *y, int n, int m) {
    if(n == 0 || m == 0) return 0;

    if(x[n-1] == y[m-1])
        return 1 + LCSRecursivo(x, y, n-1, m-1);
    else
        return max(LCSRecursivo(x, y, n, m-1), LCSRecursivo(x, y, n-1, m));
}

//Programacao Dinamica
int LCSPD(char *x, char *y, int n, int m, int** L) {
    int i, j;

    for(i=0; i<=n; i++)
        L[i][0] = 0;

    for(j=0; j<=m; j++)
        L[0][j] = 0;

    for(i=1; i<=n; i++)
        for(j=1; j<=m; j++)
            if(x[i-1] == y[j-1])
                L[i][j] = 1 + L[i-1][j-1];
            else
                L[i][j] = max(L[i-1][j], L[i][j-1]);

    return L[n][m];
}

void imprimeLCS(char *x, char *y, int n, int m, int **L) {
    if(n==0 || m==0)
        return;

    if(x[n-1] == y[m-1]) {
        imprimeLCS(x, y, n-1, m-1, L);
        cout << x[n-1];
    } else if(L[n][m] == L[n-1][m])
        imprimeLCS(x, y, n-1, m, L);
    else
        imprimeLCS(x, y, n, m-1, L);
}

int main() {
    int n, m, i, total;
    cin >> total;
    clock_t rec, pd;
    srand(time(NULL));
    n = rand()%total + 5;
    m = rand()%total + 5;
    char *X = new char[n+1];
    char *Y = new char[m+1];

    for(i=0; i<n; i++)
        X[i] = rand()%26 + 'a';
    X[i] = '\0';
    for(i=0; i<m; i++)
        Y[i] = rand()%26 + 'a';
    Y[i] = '\0';
    cout << n << ": " << X << endl;
    cout << m << ": " << Y << endl;

    //Alocacao
    int **L = new int*[n+1];
    for(i=0; i<=n; i++)
        L[i] = new int[m+1];

    //PD
    pd = clock();
    int valorMaxPD = LCSPD(X, Y, n, m, L);
    pd = clock() - pd;
    cout << "\n\nLCS: ";
    imprimeLCS(X, Y, n, m, L);
    cout << endl;
    printf("\nProgramacao Dinamica\n");
    printf("Valor: %d | %.10f segundos\n\n", valorMaxPD, ((float)pd)/CLOCKS_PER_SEC);
    //Recursivo
    rec = clock();
    int valorMaxRec = LCSRecursivo(X, Y, n, m);
    rec = clock() - rec;
    printf("Recursivo\n");
    printf("Valor: %d | %.10f segundos\n\n", valorMaxRec, ((float)rec)/CLOCKS_PER_SEC);
    //Desaloca
    delete [] X;
    delete [] Y;

    for(i=0; i<=n; i++)
        delete [] L[i];

    delete [] L;
    return 0;
}
