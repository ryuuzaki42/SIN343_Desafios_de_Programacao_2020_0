#include <iostream>
#include <map>
#include <stdio.h>
#include <set>
#include <vector>
#include <utility>

using namespace std;

int main() {
    int N, M, C, i, valores;
    cin >> N;
    int cont = 0;

    while(cont < N) {
        if(cont > 0) printf("\n");

        cin >> M >> C;
        map<int, vector<int> > hash;
        map<int, vector<int> >::iterator itm;

        for(i=0; i<M; i++) {
            vector<int> s;
            hash.insert(pair<int, vector<int> >(i, s));
        }

        for(i=0; i<C; i++) {
            cin >> valores;
            hash[valores%M].push_back(valores);
        }

        vector<int>::iterator its;

        for(itm=hash.begin(); itm!=hash.end(); itm++) {
            cout << itm->first << " -> ";

            for(its=itm->second.begin(); its!=itm->second.end(); its++)
                cout << *its << " -> ";

            cout << "\\" << endl;
        }

        cont++;
    }

    return 0;
}
