// array::at
#include <iostream>
#include <stdio.h>
#include <utility>
#include <map>
#include <set>
#include <vector>

using namespace std;

int main() {
    int N, M, C, i, chave;
    int cont = 0;
    cin >> N;

    while(cont < N) {
        if(cont > 0) printf("\n");

        cin >> M >> C;
        map<int,vector<int> > mapa;
        map<int,vector<int> >::iterator itm;
        vector<int>::iterator its;

        for(i=0; i<M; i++) {
            vector<int> conj;
            mapa.insert(pair<int,vector<int> >(i, conj));
        }

        for(i=0; i<C; i++) {
            cin >> chave;
            mapa[chave%M].push_back(chave);
        }

        for(itm=mapa.begin(); itm!=mapa.end(); itm++) {
            cout << itm->first << " -> ";// << it->second[0] << endl;

            for(its=itm->second.begin(); its!=itm->second.end(); its++)
                cout << *its << " -> ";

            cout << "\\" << endl;
        }

        cont++;
    }

    return 0;
}
