#include <iostream>
#include <list>

using namespace std;

int main() {
    list<int> lista;
    list<int>::iterator itk, itm, itk2, itm2;
    int N, k, m, i;
    cin >> N >> k >> m;

    while(N!=0 && k!=0 && m!=0) {
        for(i=1; i<=N; i++) lista.push_back(i);

        itk = lista.begin();
        itm = lista.end();
        itm--;
//         cout << " " << *itk << *itm << endl;
        bool primeira = true;

        while(!lista.empty()) {
            for(i=1; i<=(k-1); i++) {
                itk++;

                if(itk == lista.end())
                    itk = lista.begin();
            }

            for(i = 1; i<= (m-1); i++) {
                if(itm == lista.begin())
                    itm = lista.end();

                itm--;
            }

            if(!primeira)
                cout << ",";

            primeira = false;

//             cout << "K:" << *itk << " M:" << *itm << endl;
            if(itk == itm) {
                cout << ((*itk >= 100)? "":((*itk >= 10)? " ":"  ")) << *itk;
                itk2 = lista.erase(itk);
                itm2 = itk2;

                if(itk2 == lista.end())
                    itk = lista.begin();

                itk = itk2;

                if(itm2 == lista.begin())
                    itm = lista.end();

                itm--;
//                 cout << "E K:" << *itk << " M:" << *itm << endl;
            } else {
                cout << ((*itk >= 100)? "":((*itk >= 10)? " ":"  ")) << *itk;
                cout << ((*itm >= 100)? "":((*itm >= 10)? " ":"  ")) << *itm;
                itk2 = lista.erase(itk);

//                 cout << "\nE K:" << *itk2 << " M:" << *itm << endl;
                if(itk2 == itm)
                    itk2++;

                if(itk2 == lista.end())
                    itk = lista.begin();

                itk = itk2;
                itm2 = lista.erase(itm);

                if(itm2 == lista.begin())
                    itm = lista.end();

                itm--;

                if(itk2 == lista.begin())
                    itk = lista.begin();
                else
                    itk = itk2;

//                 cout << "\nE K:" << *itk2 << " M:" << *itm << endl;
//                 itm2 = lista.erase(itm2);
            }

//             cout << endl;
//             for (list<int>::iterator it=lista.begin(); it!=lista.end(); ++it)
//                cout << ' ' << *it;
//             cout << '\n';
        }

        cout << endl;
        cin >> N >> k >> m;
    }

    return 0;
}
