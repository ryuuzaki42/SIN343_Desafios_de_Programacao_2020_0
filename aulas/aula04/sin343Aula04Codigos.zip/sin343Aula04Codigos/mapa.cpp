#include <iostream>
#include <map>
#include <vector>

using namespace std;

int main() {
    map<int,vector<int> > mapa;
    map<int,vector<int> >::iterator it;
    vector<int>::iterator itv;
    vector<int> vet, vet2;

    for(int i=0; i<10; i++)
        vet.push_back(i);

    mapa.insert(pair<int, vector<int> >(0, vet));
    vet2.push_back(2);
    vet2.push_back(10);
    mapa[1] = vet2;
    cout << "map contains:" << endl;

    for(it = mapa.begin(); it != mapa.end(); it++) {
        cout << ' ' << it->first << " => ";// << it->second[0] << endl;

        for(itv=it->second.begin(); itv!=it->second.end(); itv++)
            cout << " " << *itv;

        cout << endl;
    }

    cout << '\n';
    return 0;
}
