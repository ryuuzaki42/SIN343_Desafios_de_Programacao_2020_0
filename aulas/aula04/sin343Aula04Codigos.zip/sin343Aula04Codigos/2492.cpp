// array::at
#include <iostream>
#include <stdio.h>
#include <utility>
#include <map>
#include <set>
#include <vector>
#include <string>

using namespace std;

int main() {
    int N, M, C, i, chave;
    cin >> N;

    while(N!=0) {
        vector<string> x, y;
        vector<string>::iterator itx, ity;
        string prim, lixo, seg;

        for(i=0; i<N; i++) {
            cin >> prim >> lixo >> seg;
            x.push_back(prim);
            y.push_back(seg);
        }

        //for (itx=x.begin(),ity=y.begin(); itx!=x.end(); itx++, ity++)
        //   cout << *itx  << " -> " << *ity << endl;
        map<string,vector<string> > mapaX, mapaY;
        map<string,vector<string> >::iterator itmx, itmy;

        for(itx=x.begin(),ity=y.begin(); itx!=x.end(); itx++, ity++) {
            mapaX[*itx].push_back(*ity);
            mapaY[*ity].push_back(*itx);
        }

        bool func = true, inv = true;

        //cout << "MapaX:\n";
        for(itmx=mapaX.begin(); itmx!=mapaX.end(); itmx++) {
            //cout << itmx->first << " -> ";// << it->second[0] << endl;
            //for(itx=itmx->second.begin(); itx!=itmx->second.end(); itx++)
            //   cout << *itx << " - ";
            //cout <<  endl;
            if(itmx->second.size() > 1) func = false;
        }

        //cout << "MapaY:\n";
        for(itmy=mapaY.begin(); itmy!=mapaY.end(); itmy++) {
            //cout << itmy->first << " -> ";// << it->second[0] << endl;
            //for(ity=itmy->second.begin(); ity!=itmy->second.end(); ity++)
            //   cout << *ity << " - ";
            //cout <<  endl;
            if(itmy->second.size() > 1) inv = false;
        }

        if(func)
            if(inv) printf("Invertible.\n");
            else printf("Not invertible.\n");
        else printf("Not a function.\n");

        //cout << endl;
        cin >> N;
    }

    return 0;
}
