#include<iostream>
#include<list>

using namespace std;

int main() {
    list<int> lista;
    list<int>::iterator it;

    for(int i=1; i<=5; ++i)
        lista.push_back(i); // 1 2 3 4 5

    cout << "Lista contem:";

    for(it=lista.begin(); it!=lista.end(); it++)
        cout << ' ' << *it;

    cout << '\n';
    return 0;
}
