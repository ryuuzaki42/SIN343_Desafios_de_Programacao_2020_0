#include <iostream>
#include <stdlib.h>
#include <stdio.h>

using namespace std;

struct Node {
    Node *esq;
    int valor;
    Node *dir;
};

class Tree {
public:
    Tree(); // constructor
    void insertNode(Node **, const int &);
    //void preOrderTraversal() const;
    //void inOrderTraversal() const;
    //void postOrderTraversal() const;

private:
    Node *root;
};

Tree::Tree() {
    root = 0; // indicate tree is initially empty
}

void Tree::insertNode(Node **ptr, const int & value) {
    if(*ptr == 0) {
        *ptr = new Node;
        *ptr.valor = value;
        *ptr.esq = *ptr.dir = 0;
    } else { // subtree is not empty
        if(value < (*ptr)->data)
            insertNodeHelper(&((*ptr)->leftPtr), value);
        else {
// data to insert is greater than data in current node
            if(value > (*ptr)->data)
                insertNodeHelper(&((*ptr)->rightPtr), value);
            else // duplicate data value ignored
                cout << value << " dup" << endl;
        } // end else
    } // end else
}

int main() {
    return 0;
}
