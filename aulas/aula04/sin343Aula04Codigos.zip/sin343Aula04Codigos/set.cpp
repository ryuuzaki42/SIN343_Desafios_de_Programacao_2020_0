#include <iostream>
#include <set>

using namespace std;

int main() {
    set<int> conjunto;
    set<int>::iterator it;

    for(int i=0; i<10; i++)
        conjunto.insert(i%2);

    cout << "set contains:" << endl;

    for(it=conjunto.begin(); it!=conjunto.end(); it++)
        cout << ' ' << *it;

    cout << '\n';
    return 0;
}
