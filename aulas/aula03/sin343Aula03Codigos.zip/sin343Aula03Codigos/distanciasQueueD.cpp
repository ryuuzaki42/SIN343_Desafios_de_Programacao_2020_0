#include<iostream>
#include<queue>

using namespace std;

#define N 100

int main() {
    int A[N][N];
    int n, c, i, j, atual;
    int dist[N];
    queue<int> fila;
    cin >> n >> c;

    for(i = 0; i < n; i++) {
        for(j = 0; j < n; j++) {
            cin >> A[i][j];
            //cout << A[i][j] << " ";
        }
        //cout << endl;
    }

    for(i = 0; i < n; i++)
        dist[i] = n;

    dist[c] = 0;
    fila.push(c);

    while(!fila.empty()) {
        atual = fila.front();
        fila.pop();
        cout << " atual: " << atual << endl;
        for(j = 0; j < n; j++) {
            cout << " j: " << j << " dist[j]: " << dist[j] << endl;
            if(A[atual][j] && dist[j] >= n) {
                dist[j] = dist[atual] + 1;
                fila.push(j);
                cout << " A[atual][j] " << A[atual][j] << endl;
            }
        }
    }

    for(i = 0; i < n; i++)
        cout << dist[i] << " ";

    cout << endl;
    return 0;
}
