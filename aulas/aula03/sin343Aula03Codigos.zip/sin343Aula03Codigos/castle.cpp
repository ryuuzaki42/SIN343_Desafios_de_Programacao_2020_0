#include<iostream>
#include<vector>
#include<queue>

using namespace std;

#define N 100

struct cel {
    int i, j, id;
};

int main() {
    int n, i, j;
    char grid[N][N];
    vector<cel> celulas;
    int id = 0;
    cin >> n;

    for(i = 0; i < n; i++) {
        cin >> grid[i];

        for(j = 0; j < n; j++) {
            if(grid[i][j] == '.') {
                cel c;
                c.i = i;
                c.j = j;
                c.id = id;
                id++;
                celulas.push_back(c);
            }
        }
//         cout << grid[i] << endl;
    }

    bool **vizinhas = new bool*[id];

    for(i = 0; i < id; i++)
        vizinhas[i] = new bool[id];

    for(i = 0; i < id; i++)
        for(j = 0; j < id; j++)
            vizinhas[i][j] = false;

    int ii, ij, ji, jj, lin, col;

    for(i = 0; i < celulas.size()-1; i++)
        for(j = i+1; j < celulas.size(); j++) {
            ii = celulas[i].i;
            ij = celulas[i].j;
            ji = celulas[j].i;
            jj = celulas[j].j;

            if((ii != ji && ij != jj) || (ii == ji && ij == jj));
            else {
//                 printf("%d e %d sao vizinhas\n", celulas[i].id, celulas[j].id);
                if(ii == ji) {
                    for(col = ij; col <= jj; col++)
                        if(grid[ii][col] == 'X')
                            break;
                        else if(col == jj) {
                            vizinhas[celulas[i].id][celulas[j].id] = true;
                            vizinhas[celulas[j].id][celulas[i].id] = true;
                        }
                }

                if(ij == jj) {
                    for(lin = ii; lin <= ji; lin++)
                        if(grid[lin][ij] == 'X') break;
                        else if(lin == ji) {
                            vizinhas[celulas[i].id][celulas[j].id] = true;
                            vizinhas[celulas[j].id][celulas[i].id] = true;
                        }
                }
            }
        }

//     for(i = 1; i < id; i++){
//        for(j = 1; j < id; j++)
//           cout << ((vizinhas[i][j])? "1 ":"0 ");
//        cout << endl;
//     }

    int xi, yi, xf, yf; //Posicoes iniciais e finais
    cin >> xi >> yi >> xf >> yf;
    int idi, idf;

    for(i = 0; i < celulas.size(); i++) {
        if(celulas[i].i == xi && celulas[i].j == yi) idi = celulas[i].id;

        if(celulas[i].i == xf && celulas[i].j == yf) idf = celulas[i].id;
    }

//     cout << idi << " -> " << idf << endl;
    int *dist = new int[id];
    queue<int> fila;
    int atual;

    for(i = 0; i < id; i++)
        dist[i] = N * N;

    dist[idi] = 0;

    fila.push(idi);

    while(!fila.empty()) {
        atual = fila.front();
        fila.pop();

        for(j = 0; j < id; j++) {
            if(vizinhas[atual][j] && dist[j] >= N * N) {
                dist[j] = dist[atual] + 1;
                fila.push(j);
            }
        }
    }

//     for(i = 0; i < id; i++)
//         cout << dist[i] << " ";
//     cout << endl;

    cout << dist[idf] << endl;
    delete [] dist;

    for(i = 0; i < id; i++)
        delete [] vizinhas[i];

    delete [] vizinhas;
    return 0;
}
