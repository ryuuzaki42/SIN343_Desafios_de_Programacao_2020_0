#include <iostream> // std::cout
#include <stack>    // std::stack

using namespace std;

int main() {
//     char entrada[1000];
    string entrada;
    int i, j, n;
    cin >> n;
    cin.get();

    for(i = 0; i < n; i++) {
        cin >> entrada;
        stack<char> pilha;

//         for(j = 0; j < entrada.size(); j++){
//            cout << entrada[j];
//         }
//         cout << endl;

        bool achei = false;
        for(j = 0; j < entrada.length(); j++) {
            if(achei)
                break;

            switch(entrada[j]) {
                case '(':
                case '[':
                case '{':
                    pilha.push(entrada[j]);
                    break;
                case ')':
                    if(!pilha.empty())
                        if(pilha.top() != '(')
                            achei = true;
                        else
                            pilha.pop();
                    else
                        achei = true;
                    break;
                case ']':
                    if(!pilha.empty())
                        if(pilha.top() != '[')
                            achei = true;
                        else
                            pilha.pop();
                    else
                        achei = true;
                    break;
                case '}':
                    if(!pilha.empty())
                        if(pilha.top() != '{')
                            achei = true;
                        else
                            pilha.pop();
                    else
                        achei = true;
                    break;
                default:
                    break;
            }
        }

        if(achei)
            cout << "NO\n";
        else if(pilha.empty())
            cout << "YES\n";
        else
            cout << "NO\n";
    }
    return 0;
}
