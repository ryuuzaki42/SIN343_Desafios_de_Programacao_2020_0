#include <iostream> // std::cout
#include <stack>    // std::stack

using namespace std;
int main() {
    stack<int> pilha;

    for(int i=0; i<5; ++i)
        pilha.push(i);

    cout << "Removendo elementos...";
    while(!pilha.empty()) {
        cout << ' ' << pilha.top();
        pilha.pop();
    }

    cout << '\n';
    return 0;
}
