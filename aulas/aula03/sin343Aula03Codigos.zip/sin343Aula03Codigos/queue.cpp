#include <iostream>
#include <queue>

using namespace std;

int main() {
    queue<int> fila;
    int num;
    cout << "Digite valores(0 - sair):\n";

    do {
        cin >> num;
        fila.push(num);
    } while(num);

    cout << "Valores: ";
    while(!fila.empty()) {
        cout << ' ' << fila.front();
        fila.pop();
    }

    cout << '\n';
    return 0;
}
