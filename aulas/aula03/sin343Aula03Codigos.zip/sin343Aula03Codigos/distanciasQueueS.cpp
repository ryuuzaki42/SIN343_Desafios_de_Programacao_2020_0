#include <iostream>
#include <stdio.h>

using namespace std;

#define N 100

int fila[N];
int p, u;
int dist[N];

void criafila(void) {
    p = 0;
    u = 0;
}

int filavazia(void) {
    return p >= u;
}

int tiradafila(void) {
    return fila[p++];
}

void colocanafila(int y) {
    fila[u++] = y;
}

// Esta função recebe uma matriz A
// que representa as interligações entre
// cidades 0..N-1 e preenche o vetor dist
// de modo que dist[i] seja a distância
// da cidade c à cidade i, para cada i.
void distancias(int A[][N], int c, int n) {
    int i, j;

    for(j = 0; j < n; ++j)
        dist[j] = n;

    dist[c] = 0;
    criafila();
    colocanafila(c);

    while(!filavazia()) {
        i = tiradafila();

        for(j = 0; j < n; ++j)
            if(A[i][j] == 1 && dist[j] >= n) {
                dist[j] = dist[i] + 1;
                colocanafila(j);
            }
    }
}

int main() {
    int i, j, c, n;
    cin >> n >> c;
    int A[N][N];

    for(i=0; i<n; i++)
        for(j=0; j<n; j++)
            cin >> A[i][j];

    distancias(A, c, n);
    printf("Distancias de %d ate outras cidades:\n", c);

    for(i = 0; i < n; i++)
        cout << dist[i] << " ";

    cout << endl;
    return 0;
}
