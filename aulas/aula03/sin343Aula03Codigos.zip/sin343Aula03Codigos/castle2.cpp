#include<iostream>
#include<vector>
#include<queue>

using namespace std;

#define N 100

struct cel {
    int i, j, id;
};

int main() {
    int n, i, j;
    char grid[N][N];
    vector<cel> celulas;
    int id = 0;
    cin >> n;

    for(i = 0; i < n; i++) {
        cin >> grid[i];

        for(j = 0; j < n; j++) {
            if(grid[i][j] == '.') {
                cel c;
                c.i = i;
                c.j = j;
                c.id = id;
                id++;
                celulas.push_back(c);
            }
        }
//         cout << grid[i] << endl;
    }

    bool **vizinhas = new bool*[id];

    for(i = 0; i < id; i++)
        vizinhas[i] = new bool[id];

    for(i = 0; i < id; i++)
        for(j = 0; j < id; j++)
            vizinhas[i][j] = false;

    int ii, ij, ji, jj, lin, col;

    for(i = 0; i < id-1; i++)
        for(j = i+1; j < id; j++) {
            ii = celulas[i].i;
            ij = celulas[i].j;
            ji = celulas[j].i;
            jj = celulas[j].j;

            if((ii != ji) && (ij != jj));
            else {
//                 printf("%d e %d sao vizinhas\n", celulas[i].id, celulas[j].id);
                if(ii == ji) {
                    for(col = ij; col <= jj; col++)
                        if(grid[ii][col] == 'X')
                            break;
                        else if(col == jj) {
                            vizinhas[celulas[i].id][celulas[j].id] = true;
                            vizinhas[celulas[j].id][celulas[i].id] = true;
                        }
                }

                if(ij == jj) {
                    for(lin = ii; lin <= ji; lin++)
                        if(grid[lin][jj] == 'X') break;
                        else if(lin == ji) {
                            vizinhas[celulas[i].id][celulas[j].id] = true;
                            vizinhas[celulas[j].id][celulas[i].id] = true;
                        }
                }
            }
        }

//     for(i = 0; i < id; i++){
//        for(j = 0; j < id; j++)
//           cout << vizinhas[i][j] << " ";
//        cout << endl;
//     }

    cel o, d;
    cin >> o.i >> o.j >> d.i >> d.j;

    for(i = 0; i < id; i++) {
        if(celulas[i].i == o.i && celulas[i].j == o.j)
            o.id = celulas[i].id;

        if(celulas[i].i == d.i && celulas[i].j == d.j)
            d.id = celulas[i].id;
    }

//     cout << o.id << " -> " << d.id << endl;
    int *dist = new int[id];
    queue<int> fila;
    int atual;

    for(i = 0; i < id; i++)
        dist[i] = N * N;

    dist[o.id] = 0;
    fila.push(o.id);

    while(!fila.empty()) {
        atual = fila.front();
        fila.pop();

        for(j = 0; j < id; j++) {
            if(vizinhas[atual][j] && dist[j] >= N * N) {
                dist[j] = dist[atual] + 1;
                fila.push(j);
            }
        }
    }

//     for(i = 0; i < id; i++)
//         cout << dist[i] << " ";
//     cout << endl;

    cout << dist[d.id] << endl;
    delete [] dist;

    for(i = 0; i < id; i++)
        delete [] vizinhas[i];

    delete [] vizinhas;
    return 0;
}
