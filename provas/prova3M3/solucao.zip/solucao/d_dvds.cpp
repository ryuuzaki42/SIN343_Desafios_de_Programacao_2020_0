#include<iostream>
#include<vector>

using namespace std;

int main() {
    string s;
    vector<string> v;

    getline(cin, s);
    while(s != "#") {
        v.push_back(s);
        getline(cin, s);
    }

    int total = v.size();
    int i, j;
    for(i = 0; i < total; i++)
        cout << "--";
    cout << "-\n";

    for(j = 0; j < 36; j++) {
        for(i = 0; i < total; i++) {
            if(j <= v[i].length() - 1)
                cout << "|" << v[i][j];
            else
                cout << "| ";
        }
        cout << "|\n";
    }

    for(i = 0; i < total; i++)
        cout << "--";
    cout << "-\n";
    return 0;
}
