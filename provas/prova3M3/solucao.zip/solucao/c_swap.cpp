#include<iostream>
#include<stdlib.h>

using namespace std;

int main() {
    int i, qtdUnidades;
    cin >> qtdUnidades;

    int *antes = (int*) malloc(sizeof(int)*qtdUnidades);
    int *depois = (int*) malloc(sizeof(int)*qtdUnidades);

    for(i = 0; i < qtdUnidades; i++)
        cin >> antes[i] >> depois[i];

    if(qtdUnidades == 1)
        cout << antes[0] << endl;
    else {
        int *inc = (int*) malloc(sizeof(int));
        int *dec = (int*) malloc(sizeof(int));
        int c = 0, d = 0;

        // Dividir em dois grupos: aumenta ou diminui
        for(i = 0; i < qtdUnidades; i++) {
            if(antes[i] > depois[i]) {
                if(d == 0)
                    dec[d++] = i;
                else {
                    d++;
                    dec = (int*) realloc(dec, d * sizeof(int));
                    dec[d-1] = i;
                }
            } else {
                if(c == 0)
                    inc[c++] = i;
                else {
                    c++;
                    inc = (int*) realloc(inc, c * sizeof(int));
                    inc[c-1] = i;
                }
            }
        }

        // Ordenar os que aumentam em ordem crescente
        int m, mi, j, auxJ;
        if(c > 0) {
            for(i = 0; i < c-1; i++) {
                m = antes[inc[i]];
                mi = inc[i];
                auxJ = -1;

                for(j = i+1; j < c; j++) {
                    if(antes[inc[j]] < m) {
                        m = antes[inc[j]];
                        mi = inc[j];
                        auxJ = j;
                    }
                }

                if(auxJ > 0) {
                    int aux = inc[i];
                    inc[i] = mi;
                    inc[auxJ] = aux;
                }
            }
        }

        // Ordenar os que diminuem em ordem decrescente
        if(d > 0) {
            for(i = 0; i < d-1; i++) {
                m = depois[dec[i]];
                mi = dec[i];
                auxJ = -1;

                for(j = i+1; j < d; j++) {
                    if(depois[dec[j]] > m) {
                        m = depois[dec[j]];
                        mi = dec[j];
                        auxJ = j;
                    }
                }

                if(auxJ > 0) {
                    int aux = dec[i];
                    dec[i] = mi;
                    dec[auxJ] = aux;
                }
            }
        }

        int swap = 0;
        int extra = 0;
        if(c > 0) {
            // Swap a primeira vez eh sempre o menor hd
            swap = antes[inc[0]];
            extra = depois[inc[0]] - antes[inc[0]];

            // Parte que aumenta o armazenamento
            for(i = 1; i < c; i++) {
                if((swap + extra) < antes[inc[i]])
                    swap += antes[inc[i]] - (swap + extra);

                extra = depois[inc[i]] + extra - antes[inc[i]];
            }
        }

        if(d > 0) {
            // Parte que diminui o armazenamento
            for(i = 0; i < d; i++) {
                if((swap + extra) < antes[dec[i]])
                    swap += antes[dec[i]] - (swap + extra);

                extra = depois[dec[i]] + extra - antes[dec[i]];
            }
        }
        cout << swap << endl;
        free(inc);
        free(dec);
    }
    free(antes);
    free(depois);
    return 0;
}
