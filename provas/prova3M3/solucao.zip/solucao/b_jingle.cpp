#include <iostream>

using namespace std;

int main() {
    string s;
    int comp = 1;
    double tab[7] = {1.0, 0.5, 0.25, 0.125, 0.0625, 0.03125, 0.015625};

    cin >> s;
    while(s!= "*") {
        int i, corretas = 0, ind;
        double soma = 0;

        for(i = 0; i < s.length(); i++) {
            switch(s[i]) {
                case 'W':
                    ind = 0;
                    break;
                case 'H':
                    ind = 1;
                    break;
                case 'Q':
                    ind = 2;
                    break;
                case 'E':
                    ind = 3;
                    break;
                case 'S':
                    ind = 4;
                    break;
                case 'T':
                    ind = 5;
                    break;
                case 'X':
                    ind = 6;
                    break;
                case '/':
                    ind = -1;
                    break;
                default:
                    break;
            }

            if(ind != -1)
                soma += tab[ind];
            else {
                if(soma == 1.0)
                    corretas++;

                soma = 0;
            }
        }

        cout << "Composicao " << comp << ": " << corretas << endl;
        comp++;
        cin >> s;
    }
    return 0;
}
