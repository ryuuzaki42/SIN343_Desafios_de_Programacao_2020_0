#include<iostream>
#include<math.h>

using namespace std;

int main() {
    string bin;
    int i, j, pot;
    long resDec = 0;

    cin >> bin;
    for(i = bin.size(), j = -1; i >= 0; i--, j++) {
        pot = 0;
        if(bin[i] == 49) { // 49 eh 1 em ascii
            pot = j;
            while(pot > 10) {
                pot -= 10; // (2^2 + 2^11)%6 = 0 = (2^2 +2^1)
            }
            resDec += pow(2, pot);
        }
    }

    if((resDec % 6) == 0)
        cout << "S" << endl;
    else
        cout << "N" << endl;
    return 0;
}
