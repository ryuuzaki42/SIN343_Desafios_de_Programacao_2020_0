#include <iostream>
#include <cstdlib>

using namespace std;

int main() {
    string str;
    cin >> str;
    int par = 0;
    int impar = 0;

    if(str[str.size() - 1] == '0') {
        for(int i = 0; i < str.size(); i++) {
            if(str[i] == '1') {
                if(i % 2 == 0)
                    par++;
                else
                    impar++;
            }
        }

        int dif = abs(par - impar);
        if(dif % 3 == 0)
            cout << "S" << endl;
        else
            cout << "N" << endl;
    } else
        cout << "N" << endl;
    return 0;
}
