#include<iostream>

using namespace std;

#define MAX 1000000

int tab[MAX + 1]; //versão bottom-up

int contar(int moeda[], int nMoedas, int troco) {
    int i, j, valorMoeda;
    tab[0] = 1;

    for(i = 1; i <= troco; i++)
        tab[i] = 0;

    for(i = 0; i < nMoedas; i++) {
        valorMoeda = moeda[i];

        for(j = valorMoeda; j <= troco; j++)
            tab[j] += tab[j - valorMoeda];
    }
    return tab[troco];
}

int main() {
    int n, i, troco;
    double reais;

    cin >> n >> reais;
    int *moedas = new int[n];

    reais *= 100;
    troco = reais;

    for(i = 0; i < n; i++)
        cin >> moedas[i];

    cout << contar(moedas, n, troco) << endl;

    delete [] moedas;
    return 0;
}
