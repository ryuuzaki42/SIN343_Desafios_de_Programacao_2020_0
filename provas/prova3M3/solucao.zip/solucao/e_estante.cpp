#include<iostream>
#include<queue>

using namespace std;

struct livro {
    int id, lar;
};

int main() {
    int t, n = 1;
    string c;
    deque<livro> d;
    cin >> t;

    while(t != -1) {
        d.clear();
        int i, id;
        cin >> c;

        while(c != "E") {
            int pos = -1, soma = 0;

            if(c == "A") {
                livro l;
                cin >> l.id >> l.lar;
                d.push_front(l);

                for(i = 0; i < d.size(); i++)
                    soma += d[i].lar;

                while(soma > t) {
                    soma -= d[d.size()-1].lar;
                    d.pop_back();
                }
            } else {
                cin >> id;

                for(i = 0; i < d.size(); i++)
                    if(d[i].id == id) {
                        pos = i;
                        break;
                    }

                if(pos != -1)
                    d.erase(d.begin() + pos);
            }
            cin >> c;
        }
        cout << "PROBLEM "<< n << ":";
        for(i = 0; i < d.size(); i++)
            cout << " " << d[i].id;
        cout << endl;

        n++;
        cin >> t;
    }
    return 0;
}
