#include <stdio.h>
#include <cmath>

int main() {
    int k, i, n, m;
    long long int temp1, temp2, qtdN, qtdM, qtdT, result;
    // unsigned long long int result;
    scanf("%d", &k);

    for(i = 0; i < k; i++) {
        scanf("%d %d", &n, &m);

        if(n < 0) {
            temp1 = n + m;
            qtdN = n * (-1);
            qtdM = m + 1;
            qtdT = qtdN + qtdM;
            result = (temp1 * qtdT)/2;
            printf("Caso #%d: %lld\n", i+1, result);
        } else {
            temp1 = n + m;
            temp2 = (m - n) + 1;
            result = (temp1 * temp2)/2;
            printf("Caso #%d: %lld\n", i+1, result);
        }
    }

    return 0;
}
