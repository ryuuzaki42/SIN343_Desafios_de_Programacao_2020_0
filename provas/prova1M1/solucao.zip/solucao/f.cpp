#include<stdio.h>
#include<math.h>

bool ePrimo(int a) {
    int i;

    for(i = 3; i <= (int)sqrt(a); i++) {
        if(a % i == 0)
            return false;
    }

    return true;
}

int main() {
    int t, n, i, j, l;
    scanf("%d", &t);

    for(l = 0; l < t; l++) {
        scanf("%d", &n);
        i = 3;
        j = (n*2) - 2;

        if(j % 2 == 0)
            j--;

        while(i != j) {
            if(ePrimo(i)) {
                if(ePrimo(j)) {
                    printf("%d %d\n", i, j);
                    break;
                }
            }

            i+=2;
            j-=2;
        }
    }

    return 0;
}
