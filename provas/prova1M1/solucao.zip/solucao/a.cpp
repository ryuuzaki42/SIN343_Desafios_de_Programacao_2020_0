#include <stdio.h>
#include <iostream>

using namespace std;

int main() {
    int x1,y1,x2,y2;
    cin >> x1;
    cin >> y1;
    cin >> x2;
    cin >> y2;
    int i = x1;
    int j = y1;

    if(x1 == x2 && y1 == y2) {
        printf("0\n");
        return 0;
    }

    if(x1 == x2 || y1 == y2) {
        printf("1\n");
        return 0;
    }

    while(i >= 1 && j >=1) {
        if(i == x2 && j == y2) {
            printf("1\n");
            return 0;
        }

        i--;
        j--;
    }

    i = x1;
    j = y1;

    while(i >= 1 && j <= 8) {
        if(i == x2 && j == y2) {
            printf("1\n");
            return 0;
        }

        i--;
        j++;
    }

    i = x1;
    j = y1;

    while(i <= 8 && j >= 1) {
        if(i == x2 && j == y2) {
            printf("1\n");
            return 0;
        }

        i++;
        j--;
    }

    i = x1;
    j = y1;

    while(i <= 8 && j <=8) {
        if(i == x2 && j == y2) {
            printf("1\n");
            return 0;
        }

        i++;
        j++;
    }

    printf("2\n");
    return 0;
}