#include <stdio.h>

int main() {
    int N, a, b, c, delta;
    scanf("%d", &N);

    for(int i = 0; i < N; i++) {
        scanf("%d %d %d", &a, &b, &c);
        delta = ((b*b) - 4*(a*c));

        if(delta > 0)
            printf("2\n");
        else if(delta == 0)
            printf("1\n");
        else
            printf("0\n");
    }

    return 0;
}
