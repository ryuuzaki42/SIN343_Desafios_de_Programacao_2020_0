#include <stdio.h>

#define SIZE 1000001

int main() {
    int i = 0;
    char w1[SIZE], w2[SIZE];
    int cl[26];
    int contAst = 0 ;
    scanf("%s %s", w1, w2);

    for(i = 0; i < 26; i++)
        cl[i] = 0;

    //Conta tam. w1
    for(i = 0; i < SIZE; i++) {
        if(w1[i] == '\0') {
            if(w2[i] == '\0')
                break;
            else {
                printf("%c\n", 'N');
                return 0;
            }
        } else if(w2[i] == '\0') {
            printf("%c\n", 'N');
            return 0;
        }

        cl[((int)w1[i] % 26)] += 1;

        if(w2[i] == '*')
            contAst++;
        else
            cl[((int)w2[i] % 26)] -= 1;
    }

    for(i = 0; i < 26; i++) {
        if(cl[i] != 0) {
            if((contAst > 0) && (contAst >= cl[i])) {
                contAst -= cl[i];
                cl[i] = 0;
            } else {
                printf("%c\n", 'N');
                return 0;
            }
        }
    }

    for(i = 0; i < 26; i++)
        if(cl[i] != 0) {
            printf("%c\n", 'N');
            return 0;
        }

    printf("%c\n", 'S');
    return 0;
}
