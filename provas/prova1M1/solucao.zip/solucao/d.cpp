#include<iostream>

using namespace std;

int main() {
    int vetor[1000];
    int n, i, cont=1, dif_prev, dif;
    cin >> n;

    for(i = 0; i < n; i++)
        cin >> vetor[i];

    dif_prev = vetor[0] - vetor[1];

    for(i = 1; i < n-1; i++) {
        dif = vetor[i] - vetor[i+1];

        if(dif != dif_prev) {
            cont++;
            dif_prev = dif;
        }
    }

    cout << cont << endl;
    return 0;
}
