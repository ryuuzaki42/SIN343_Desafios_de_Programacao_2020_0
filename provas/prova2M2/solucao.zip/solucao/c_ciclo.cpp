#include<iostream>

using namespace std;

int main() {
    int i, j, n;
    int ciclo;
    int max;

    while(cin >> i >> j) {
        max = 0;
        int dif = i - j;
        int t;

        if(dif == 0) {
            t = 0;
            ciclo = 0;
            n = i;

            while(true) {
                ciclo++;

                if(n == 1)
                    break;

                if(n%2 ==0)
                    n /= 2;
                else
                    n = (3 * n+1);
            }

            max = ciclo;
        } else if(dif > 0)
            t = -1;
        else
            t = 1;

        for(int x = i; x != (j + t); x += t) {
            ciclo = 0;
            n = x;

            while(true) {
                ciclo++;

                if(n == 1)
                    break;

                if(n%2 == 0)
                    n /= 2;
                else
                    n = (3 * n+1);
            }

            if(max < ciclo)
                max = ciclo;
        }
        cout << i << " " << j << " " << max <<endl;
    }
    return 0;
}
