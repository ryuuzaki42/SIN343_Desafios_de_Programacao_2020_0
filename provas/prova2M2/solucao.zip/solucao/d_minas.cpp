#include<iostream>

using namespace std;

bool e_viz(int i, int j, int n, int m) {
    if((i >= 0 && i < n) && (j >= 0 && j < m))
        return true;
    return false;
}

int main() {
    string campo[100];
    int minas[100][100];
    int m, n, i, j, x, y;
    int campos = 0;
    cin >> n >> m;

    while(n != 0 && m != 0) {
        if(campos != 0)
            cout << endl;

        for(i = 0; i < n; i++) {
            for(j = 0; j < m; j++)
                minas[i][j] = 0;
        }

        for(i = 0; i < n; i++) {
            cin >> campo[i];
//             cout << campo[i] << endl;
        }

        for(i = 0; i < n; i++) {
            for(j = 0; j < m; j++) {
                if(campo[i][j] == '*') {
                    x = i - 1;
                    y = j - 1;
                    if(e_viz(x, y, n, m))
                        if(campo[x][y] == '.')
                            minas[x][y]++;

                    x = i - 1;
                    y = j;
                    if(e_viz(x, y, n, m))
                        if(campo[x][y] == '.')
                            minas[x][y]++;

                    x = i - 1;
                    y = j + 1;
                    if(e_viz(x, y, n, m))
                        if(campo[x][y] == '.')
                            minas[x][y]++;

                    x = i;
                    y = j - 1;
                    if(e_viz(x, y, n, m))
                        if(campo[x][y] == '.')
                            minas[x][y]++;

                    x = i;
                    y = j + 1;
                    if(e_viz(x, y, n, m))
                        if(campo[x][y] == '.')
                            minas[x][y]++;

                    x = i + 1;
                    y = j - 1;
                    if(e_viz(x, y, n, m))
                        if(campo[x][y] == '.')
                            minas[x][y]++;

                    x = i + 1;
                    y = j;
                    if(e_viz(x, y, n, m))
                        if(campo[x][y] == '.')
                            minas[x][y]++;

                    x = i + 1;
                    y = j + 1;
                    if(e_viz(x, y, n, m))
                        if(campo[x][y] == '.')
                            minas[x][y]++;
                }
            }
        }
        cout << "Campo #" << campos + 1 << ":" << endl;
        for(i = 0; i < n; i++) {
            for(j = 0; j < m; j++) {
                if(campo[i][j] == '*')
                    cout << campo[i][j];
                else
                    cout << minas[i][j];
            }
            cout << endl;
        }
        campos++;
        cin >> n >> m;
    }
    return 0;
}
