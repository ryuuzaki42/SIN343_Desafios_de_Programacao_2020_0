#include <iostream>
#include <queue>

using namespace std;

struct papel {
    int pri;
    int id;
};

int main() {
    int casos, cont, n, m, i, tempo;
    cin >> casos;

    for(cont = 0; cont < casos; cont++) {
        cin >> n >> m;
        deque<papel> d;
        bool imprimiu = false;
        papel atual;
        tempo = 0;

        for(i = 0; i < n; i++) {
            cin >> atual.pri;
            atual.id = i;
            d.push_back(atual);
        }

        while(!imprimiu) {
            atual.pri = d[0].pri;
            atual.id = d[0].id;
            bool imprime = true;
            d.pop_front();

            for(i = 0; i< d.size(); i++)
                if(d[i].pri > atual.pri) {
                    d.push_back(atual);
                    imprime = false;
                    break;
                }

            if(imprime) {
                if(atual.id == m)
                    imprimiu = true;

                tempo++;
            }
        }
        cout <<  tempo << endl;
        d.clear();
    }
    return 0;
}
