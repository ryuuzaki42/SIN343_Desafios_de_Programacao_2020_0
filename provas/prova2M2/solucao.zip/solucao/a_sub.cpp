#include <iostream>

using namespace std;

int main() {
    int cont, c, n, s, i, ini, fim, tam;
    int *num;
    int *subs;

    cin >> c;
    for(cont = 0; cont < c; cont++) {
        cin >> n >> s;
        num = new int[n];
        subs = new int[n];
        ini = fim = 0;
        tam = n + 1;
        bool achei = false;

        for(i = 0; i < n; i++) {
            cin >> num[i];
            subs[i] = num[i];

            if(i > 0) {
                subs[i] += subs[i-1];
                fim = i;
            }

            if(subs[i] >= s) {
                achei = true;

                while((subs[i] - num[ini]) >= s) {
                    subs[i] -= num[ini];
                    ini++;
                }

                if(((fim - ini) + 1) < tam)
                    tam = (fim - ini) + 1;
            }
        }

        if(!achei)
            tam = 0;

        cout << "Caso " << cont+1 << ": " << tam << endl;
        delete [] num;
        delete [] subs;
    }
    return 0;
}
