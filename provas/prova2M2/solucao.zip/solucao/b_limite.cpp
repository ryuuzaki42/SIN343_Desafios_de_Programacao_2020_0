#include<iostream>

using namespace std;

int main() {
    int n, v, h, ha, i;
    int d;

    while(true) {
        d = 0;
        ha = 0;

        cin >> n;
        if(n == -1)
            break;

        for(i = 1; i <= n; i++) {
            cin >> v >> h;
            d += (v * (h - ha));
            ha = h;
        }
        cout << d << " miles" << endl;
    }
    return 0;
}
