#include<iostream>
#include<vector>
#include<algorithm>

using namespace std;

struct equipe {
    string nome;
    int tentativas[4];
    int tempo[4];
    int resolvidos;
    int final;
};

bool compare(equipe a, equipe b) {
    if(a.resolvidos > b.resolvidos)
        return true;

    if(a.resolvidos < b.resolvidos)
        return false;

    if(a.final < b.final)
        return true;

    if(a.final > b.final)
        return false;
}

int main() {
    int n, i, j;
    cin >> n;
    vector<equipe> v;

    for(i = 0; i < n; i++) {
        equipe t;
        t.resolvidos = 0;
        t.final = 0;
        cin >> t.nome;

        for(j = 0; j < 4; j++) {
            cin >> t.tentativas[j] >> t.tempo[j];

            if(t.tempo[j] != 0) {
                t.resolvidos++;
                t.final += (t.tempo[j] + (t.tentativas[j]-1) * 20);
            }
        }

        v.push_back(t);
    }

    sort(v.begin(), v.end(), compare);
    cout << v[0].nome << " " << v[0].resolvidos << " " << v[0].final << endl;
    return 0;
}
